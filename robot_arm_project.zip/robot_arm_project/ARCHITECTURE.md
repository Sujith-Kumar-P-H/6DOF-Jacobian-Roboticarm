# Architecture: one-page map

Read this first. The program is split so that **each file answers one question**, and data flows in one direction.

```
config.py ──► kinematics.py ──► controller.py ──► simulator.py ──► mission.py ──► pick_place_robot.py
 (numbers)    (robot shape)     (control loops)    (move + record)   (the job)       (command line)
                                                         │
                                                         ▼
                                  recorder.py ──► visuals/*  (pictures)   and   trajectory_io.py (JSON)
```

Nothing to the right is imported by anything to the left. `visuals/` never changes robot behaviour.

## The files

| File | Question it answers | Main things inside |
|---|---|---|
| `armsim/config.py` | What are the numbers? | `DH_TABLE`, `RobotSpec` (limits, **payload**), `ControllerGains`, `SHELVES`, `DEFAULT_ORDERS`, `HOME_Q`, `VisualConfig` |
| `armsim/maths3d.py` | Rotation maths | `rotvec_to_R`, `R_to_rotvec`, `frame_from_zy`, `quintic` |
| `armsim/kinematics.py` | Where is the tool? How does it move? | class `Arm6`: `fk`, `fk_jac`, `ik`, `dls_pinv`, `manipulability` |
| `armsim/trajectories.py` | Where should the tool be at time t? | `CartSegment` (straight line), `JointSegment` (joint-space move) |
| `armsim/workcell.py` | What is in the world? | `Item`, `item_center`, `tote_slot`, `cycle_key_poses` |
| `armsim/controller.py` | How does it follow the path? | `ClikController` (outer loop), `JointServo` (inner PID) |
| `armsim/gripper.py` | Does the suction hold? | `SuctionGripper.engage / release` |
| `armsim/simulator.py` | Run the loops and move | `Simulator.step / goto / goto_joint / dwell` |
| `armsim/mission.py` | What is the job? | `PickingMission.retrieve_and_place`, payload rule, `report` |
| `armsim/recorder.py` | What happened? | `Recorder` → `RunData` (numpy arrays for plots) |
| `armsim/trajectory_io.py` | Save the run | `save_trajectory` → `trajectory.json`, `load_trajectory` |
| `armsim/dh_check.py` | Is my edited DH table sane? | `check_dh` (`--check-dh`) |
| `armsim/selftest.py` | Does everything still work? | `run_tests` (`--test`) |
| `armsim/visuals/theme.py` | Colours and fonts | `DARK`, `LIGHT`, `apply_theme` |
| `armsim/visuals/panels.py` | The graphs | one function per graph, `@panel('key', 'Title')` |
| `armsim/visuals/scene3d.py` | The 3D picture | `Scene3D` |
| `armsim/visuals/figures.py` | The still PNGs | `FIGURES` dict |
| `armsim/visuals/animation.py` | Video, GIF, window | `Animation` |

## The few data types (everything else is plain numbers)

| Type | Where | What it is |
|---|---|---|
| `DHTable` / `DHRow` | config | the robot geometry (6 rows) |
| `RobotSpec` | config | DH table + joint limits + tool + payload rating |
| `ShelfSpec` | config | one shelf: position, direction, columns, levels |
| `Item` | workcell | one cube: name, shelf, level, column, **mass**, position, state |
| `CycleRecord` | mission | result of one order (status, tries, errors, time) |
| `RunData` | recorder | all logged arrays; the only thing the visuals read |

Poses are always a position `p` (3-vector, metres) and a rotation `R` (3×3). Joint angles `q` are 6-vectors in radians.

## One pick-and-place cycle (mission.py)

`payload check → reachability check → approach pre-grasp (joint move) → insert along the shelf axis → suction + vacuum check (retry up to 3) → retract (retrieval) → transit → above tote → lower → release → clear` … then `return HOME` after the last order.

## "I want to change … → edit …"

| I want to | Edit |
|---|---|
| change the robot's link lengths / angles | `config.py` → `UR5_STANDARD` (or a JSON file, `--dh my_dh.json`). Then run `--check-dh` |
| change the maximum payload | `config.py` → `RobotSpec.max_payload_kg`, `tool_mass_kg` |
| add or change an item or its weight | `config.py` → `DEFAULT_ORDERS` `(name, level, col, shelf, mass_kg)` |
| move a shelf / add a third shelf | `config.py` → `SHELVES` (one `ShelfSpec` each) |
| move the tote | `config.py` → `TOTE_CENTER` |
| change speed / smoothness of the control | `config.py` → `ControllerGains` |
| change suction rules or retry count | `config.py` (`SEAL_*`, `MAX_GRASP_ATTEMPTS`) |
| change colours or fonts | `visuals/theme.py` |
| add a graph | `visuals/panels.py` (copy a function, change the decorator key) → use `--panels joints,mykey` |
| add a PNG image | `visuals/figures.py` → `FIGURES` |
| change what is saved in the JSON | `trajectory_io.py` |
| change the order of the mission steps | `mission.py` → `retrieve_and_place` |
| add a new kind of motion | `trajectories.py` (new class with `.T`, `.sample(t)`, `.p1`, `.R1`, `.label`) |

## Rules that keep it understandable

1. A number you might tune lives in `config.py`, never inside a function.
2. `visuals/` reads `RunData`; it never touches the robot.
3. Every file starts with a docstring saying what it is for.
4. After any change run `python3 pick_place_robot.py --test`. It includes a regression test: the original 4-order mission must still give 72.2 s total and 0.2 mm error.
