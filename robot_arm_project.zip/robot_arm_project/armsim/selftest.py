"""
selftest.py -- run with:  python pick_place_robot.py --test      (no files are left behind)

Groups:
  A. kinematics     FK, Jacobian, IK, singularities, rotations, trajectories      (your original tests)
  B. DH tables      both conventions agree; JSON tables load; a wrong-convention table is detected
  C. mission        original 4-order mission reproduces the reference numbers, shelf 2, payload rule, retry logic
  D. outputs        trajectory.json round trip, headless render (no window), theme/panel registry
"""
from __future__ import annotations

import math
import tempfile
from pathlib import Path

import numpy as np

from .config import (BASELINE_ORDERS, HOME_Q, ITEM_SIZE, ROBOT, TOTE_CENTER, TOTE_FLOOR_Z, UR5_MODIFIED, UR5_STANDARD,
                     DHRow, DHTable, RobotSpec, VisualConfig)
from .kinematics import Arm6
from .maths3d import R_to_rotvec, rotvec_to_R
from .mission import PickingMission
from .simulator import Simulator
from .trajectories import CartSegment
from .workcell import R_FWD, make_items


def _run(orders, seed, slip, arm=None):
    sim = Simulator(arm or Arm6(), make_items(orders), np.random.default_rng(seed), slip_prob=slip)
    m = PickingMission(sim)
    m.run()
    return sim, m


def run_tests():
    ok_all = True
    rng = np.random.default_rng(0)
    arm = Arm6()

    def check(name, cond, info=''):
        nonlocal ok_all
        ok_all &= bool(cond)
        print(f"[{'PASS' if cond else 'FAIL'}] {name} {info}")

    print('--- A. kinematics ---')
    a0 = Arm6(RobotSpec(tool_len=0.0, base_yaw=0.0))
    p, R = a0.fk(np.zeros(6))
    check('FK: matches known UR5 zero pose (flange)', np.allclose(p, [-0.81725, -0.19145, -0.005491], atol=1e-5), f'(p={np.round(p, 5)})')
    p, R = arm.fk(HOME_Q)
    check('FK: rotation matrix is orthonormal, det=+1', np.allclose(R @ R.T, np.eye(3), atol=1e-12) and abs(np.linalg.det(R) - 1) < 1e-12)
    worst = 0
    for _ in range(100):
        q = rng.uniform(-math.pi, math.pi, 6)
        _, _, J = arm.fk_jac(q)
        worst = max(worst, np.max(np.abs(J - arm.jacobian_numeric(q))))
    check('Jacobian: analytic == finite difference (100 random poses)', worst < 1e-4, f'(max diff {worst:.1e})')
    q = np.radians([10, -80, 100, -100, -90, 20])
    _, _, J = arm.fk_jac(q)
    dq = rng.normal(size=6) * 1e-4
    p0, R0 = arm.fk(q); p1, R1 = arm.fk(q + dq)
    check('Jacobian: J*dq predicts the TCP displacement', np.linalg.norm(J[:3] @ dq - (p1 - p0)) < 1e-8)
    fails, worst = 0, 0
    for _ in range(50):
        qt = HOME_Q + rng.normal(0, 0.35, 6)
        pt, Rt = arm.fk(qt)
        qs, ok, _, _ = arm.ik(pt, Rt, HOME_Q)
        fails += (not ok)
        if ok:
            worst = max(worst, np.linalg.norm(arm.fk(qs)[0] - pt))
    check('IK (DLS): reaches 50 random reachable poses from HOME seed', fails <= 2 and worst < 1e-5, f'({fails} failures, worst {worst:.1e} m)')
    _, ok, ep_, _ = arm.ik(np.array([1.5, 0.0, 0.5]), R_FWD, HOME_Q)
    check('IK: target outside workspace is rejected', not ok, f'(residual {ep_:.2f} m)')
    qs = np.radians([0, -90, 0, -90, -90, 0])
    _, _, Js = arm.fk_jac(qs)
    w, smin = arm.manipulability(Js)
    check('Singularity: stretched arm has sigma_min ~ 0', smin < 1e-6, f'(sigma_min={smin:.1e}, w={w:.1e})')
    qd = arm.dls_pinv(Js) @ np.array([0.2, 0, 0, 0, 0, 0])
    check('Singularity: DLS keeps joint velocity finite', np.max(np.abs(qd)) < 20.0, f'(max qdot {np.max(np.abs(qd)):.2f} rad/s)')
    wv = np.array([0.3, -0.5, 0.2])
    check('Rotation log/exp round trip', np.allclose(R_to_rotvec(rotvec_to_R(wv)), wv, atol=1e-10))
    seg = CartSegment(np.zeros(3), np.eye(3), np.array([0.3, 0.1, 0.2]), rotvec_to_R(wv))
    _, _, v0, _ = seg.sample(0)
    p1_, R1_, _, w1 = seg.sample(seg.T)
    check('Trajectory: starts/ends at the poses with zero velocity', np.allclose(p1_, [0.3, 0.1, 0.2]) and np.allclose(R1_, rotvec_to_R(wv), atol=1e-9) and np.allclose(v0, 0) and np.allclose(w1, 0))

    print('--- B. DH tables ---')
    am = Arm6(RobotSpec(dh=UR5_MODIFIED))
    dp = dr = dj = 0.0
    for _ in range(100):
        q = rng.uniform(-math.pi, math.pi, 6)
        ps, Rs, Js_ = arm.fk_jac(q)
        pm, Rm, Jm = am.fk_jac(q)
        dp, dr, dj = max(dp, np.abs(ps - pm).max()), max(dr, np.abs(Rs - Rm).max()), max(dj, np.abs(Js_ - Jm).max())
    check('Standard and modified DH describe the SAME robot (FK + Jacobian agree)', max(dp, dr, dj) < 1e-12, f'(max diff {max(dp, dr, dj):.1e})')
    wm = max(np.abs(am.jacobian_numeric(q) - am.fk_jac(q)[2]).max() for q in rng.uniform(-3, 3, (20, 6)))
    check('Modified DH: analytic Jacobian == finite difference', wm < 1e-4, f'({wm:.1e})')
    with tempfile.TemporaryDirectory() as td:
        f = Path(td) / 'dh.json'
        UR5_STANDARD.to_json(f)
        back = DHTable.from_json(f)
        same = all(abs(getattr(a, k) - getattr(b, k)) < 1e-12 for a, b in zip(UR5_STANDARD.rows, back.rows) for k in ('d', 'a', 'alpha', 'theta_offset'))
        check('DH table JSON save/load round trip', same and back.convention == 'standard')
    longer = DHTable(rows=tuple(DHRow(r.d, r.a * 1.05 if i == 1 else r.a, r.alpha) for i, r in enumerate(UR5_STANDARD.rows)))
    p_long = Arm6(RobotSpec(dh=longer)).fk(HOME_Q)[0]
    check('Editing the DH table changes the robot (upper arm +5 % moves the tool)', np.linalg.norm(p_long - arm.fk(HOME_Q)[0]) > 0.01,
          f'(tool moved {np.linalg.norm(p_long - arm.fk(HOME_Q)[0])*1000:.0f} mm)')

    print('--- C. mission ---')
    sim, m = _run(BASELINE_ORDERS, 2, 0.0)
    st = {r.name: r.status for r in m.records}
    check('Mission: reachable orders A,B,C placed; unreachable D skipped', st == {'A': 'OK', 'B': 'OK', 'C': 'OK', 'D': 'SKIPPED'}, f'({st})')
    d = sim.recorder.finish()
    check('Mission: no tracking fault, max task error < 20 mm', (not sim.fault) and d.ep_mm.max() < 20, f'(max {d.ep_mm.max():.1f} mm)')
    check('Reference numbers of the original script (72.2 s total, 0.2 mm max error)', abs(sim.t - 72.2) < 0.05 and d.ep_mm.max() < 0.3,
          f'(t={sim.t:.2f} s, err={d.ep_mm.max():.2f} mm)')
    p_end, _ = sim.arm.fk(sim.q)
    check('Mission: returns to HOME within 1 mm', np.linalg.norm(p_end - arm.fk(HOME_Q)[0]) < 1e-3)
    placed = [it for it in sim.items if it.state == 'placed']
    check('Mission: placed items end up in the tote footprint', all(abs(it.pos[0] - TOTE_CENTER[0]) < .08 and abs(it.pos[1] - TOTE_CENTER[1]) < .08 and abs(it.pos[2] - (TOTE_FLOOR_Z + ITEM_SIZE / 2)) < .003 for it in placed))

    sim2, m2 = _run([('A', 0, 0)], 1, 0.7)
    check('Retry logic: eventually grasps or reports GRASP_FAIL', m2.records[0].status in ('OK', 'GRASP_FAIL'), f"({m2.records[0].status}, {m2.records[0].attempts} attempts)")

    sim3, m3 = _run([('E', 1, 0, 1, 1.0)], 2, 0.0)
    it = sim3.items[0]
    check('Second shelf (behind the robot): item retrieved and placed in the tote', m3.records[0].status == 'OK' and it.state == 'placed' and it.pos[0] > 0,
          f'({m3.records[0].status}, final x={it.pos[0]:.2f} m)')

    spec = ROBOT
    sim4, m4 = _run([('H', 0, 0, 0, spec.item_payload_limit_kg + 0.1), ('J', 0, 0, 0, spec.item_payload_limit_kg - 0.1)], 2, 0.0)
    check('Payload rule: item above the limit is rejected (OVERLOAD), item just below is not',
          m4.records[0].status == 'OVERLOAD' and m4.records[1].status == 'OK', f'({m4.records[0].status}, {m4.records[1].status}, limit {spec.item_payload_limit_kg} kg)')
    check('Payload rule: the rejected item never moved', np.allclose(sim4.items[0].pos, make_items([('H', 0, 0, 0)])[0].pos))

    print('--- D. outputs ---')
    from .trajectory_io import load_trajectory, save_trajectory
    with tempfile.TemporaryDirectory() as td:
        f = Path(td) / 'trajectory.json'
        save_trajectory(f, sim3.arm, sim3.recorder.finish(), sim3, m3, 2, 0.0)
        doc = load_trajectory(f)
        s = doc['samples']
        n = len(s['t_s'])
        check('trajectory.json: loads, all columns have the same length', all(len(s[k]) == n for k in s) and n == len(sim3.recorder.finish().t), f'({n} samples)')
        q_back = np.radians(np.array(s['joint_deg']))
        check('trajectory.json: joint angles match the simulation (<0.01 deg)', np.abs(q_back - sim3.recorder.finish().q).max() < math.radians(0.01))
        check('trajectory.json: contains payload rating and phases', doc['robot']['item_payload_limit_kg'] == spec.item_payload_limit_kg and len(doc['phases']) > 3)

    import matplotlib
    from .visuals import render_all
    from .visuals.panels import PANELS
    from .visuals.theme import THEMES
    check('Visuals: every panel is registered', {'joints', 'error', 'orient', 'manip', 'manip_w', 'velocity', 'speed', 'payload'} <= set(PANELS))
    with tempfile.TemporaryDirectory() as td:
        for theme in THEMES:
            vis = VisualConfig(theme=theme, formats=['png'], panels=['joints', 'payload'], show_window=False)
            saved = render_all(sim3.arm, sim3.recorder.finish(), vis, Path(td) / theme)
            check(f'Render ({theme} theme): PNG files written', len(saved) >= 6 and all((Path(td) / theme / s).stat().st_size > 5000 for s in saved), f'({len(saved)} files)')
        check('Render without --show: headless backend, no window', matplotlib.get_backend().lower() == 'agg', f'(backend={matplotlib.get_backend()})')

    print('\nALL TESTS PASSED' if ok_all else '\nSOME TESTS FAILED')
    return ok_all
