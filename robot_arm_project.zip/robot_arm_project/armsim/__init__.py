"""armsim -- 6-axis pick-and-place simulation. Start reading at ARCHITECTURE.md (one-page map of the modules)."""
