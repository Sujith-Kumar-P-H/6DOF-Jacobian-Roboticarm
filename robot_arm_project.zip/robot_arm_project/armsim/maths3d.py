"""
maths3d.py -- small pure-math helpers for 3D rotations and time scaling. No robot knowledge in here.

    skew(v)             3-vector -> 3x3 cross-product matrix
    rotvec_to_R(w)      rotation vector (axis * angle) -> rotation matrix   (matrix exponential)
    R_to_rotvec(R)      rotation matrix -> rotation vector                  (matrix logarithm)
    frame_from_zy(z,y)  build a rotation matrix whose z-axis points along z
    quintic(tau)        smooth 0->1 curve with zero velocity/acceleration at both ends
"""
from __future__ import annotations

import math

import numpy as np


def skew(v):
    return np.array([[0, -v[2], v[1]], [v[2], 0, -v[0]], [-v[1], v[0], 0]])


def rotvec_to_R(w):
    """rotation vector (axis * angle) -> rotation matrix."""
    th = float(np.linalg.norm(w))
    if th < 1e-12:
        return np.eye(3)
    K = skew(w / th)
    return np.eye(3) + math.sin(th) * K + (1 - math.cos(th)) * (K @ K)


def R_to_rotvec(R):
    """Rotation matrix -> rotation vector (matrix logarithm). Valid for angle < pi."""
    c = max(-1.0, min(1.0, (np.trace(R) - 1) / 2))
    th = math.acos(c)
    v = np.array([R[2, 1] - R[1, 2], R[0, 2] - R[2, 0], R[1, 0] - R[0, 1]])
    if th < 1e-9:
        return 0.5 * v
    if math.pi - th < 1e-4:                       # near 180 deg the antisymmetric part vanishes
        A = (R + np.eye(3)) / 2
        axis = np.sqrt(np.maximum(np.diag(A), 0))
        axis[1] = math.copysign(axis[1], R[0, 1] + R[1, 0]) if axis[1] > 1e-9 else 0
        axis[2] = math.copysign(axis[2], R[0, 2] + R[2, 0]) if axis[2] > 1e-9 else 0
        return th * axis / max(np.linalg.norm(axis), 1e-12)
    return th / (2 * math.sin(th)) * v


def frame_from_zy(z_dir, y_hint):
    """Right-handed rotation matrix whose tool z-axis points along z_dir."""
    z = np.asarray(z_dir, float) / np.linalg.norm(z_dir)
    x = np.cross(y_hint, z)
    x /= np.linalg.norm(x)
    y = np.cross(z, x)
    return np.column_stack([x, y, z])


def quintic(tau):
    """Returns (s, ds/dtau): zero velocity and acceleration at both ends."""
    tau = min(max(tau, 0.0), 1.0)
    return 10 * tau**3 - 15 * tau**4 + 6 * tau**5, 30 * tau**2 - 60 * tau**3 + 30 * tau**4
