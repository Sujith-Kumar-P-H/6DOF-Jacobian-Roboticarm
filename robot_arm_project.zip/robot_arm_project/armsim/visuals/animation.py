"""
animation.py -- the video / GIF / interactive window.

Layout:  [ 3D scene (left) | stacked graph panels (right) ]  + status strip (bottom)
The panels shown are whatever VisualConfig.panels lists (default: joints, error, manip).

    anim = Animation(plt, arm, data, theme, vis, fonts)
    anim.save_video(path)      # mp4 (needs ffmpeg; imageio-ffmpeg supplies it)
    anim.save_gif(path)        # GIF via Pillow (fewer frames, smaller dpi)
    anim.show()                # interactive window with check-box toggles (only when --show was passed)
"""
from __future__ import annotations

from .panels import PANELS
from .scene3d import Scene3D


def _writer(kind, fps):
    import matplotlib
    import matplotlib.animation as manim
    if kind == 'mp4':
        try:
            import imageio_ffmpeg
            matplotlib.rcParams['animation.ffmpeg_path'] = imageio_ffmpeg.get_ffmpeg_exe()
        except Exception:
            pass
        if not manim.writers.is_available('ffmpeg'):
            return None
        return manim.FFMpegWriter(fps=fps, bitrate=2500)
    return manim.PillowWriter(fps=fps)


class Animation:
    def __init__(self, plt, arm, data, theme, vis, fonts):
        from matplotlib.animation import FuncAnimation
        self.plt, self.d, self.th, self.vis, self.fonts, self.FuncAnimation = plt, data, theme, vis, fonts, FuncAnimation
        keys = [k for k in vis.panels if k in PANELS]
        fig = plt.figure(figsize=(13, 7.2))
        if keys:
            gs = fig.add_gridspec(len(keys), 2, width_ratios=[1.5, 1], hspace=0.55, wspace=0.12,
                                  left=0.02, right=0.97, top=0.90, bottom=0.08)
            ax3 = fig.add_subplot(gs[:, 0], projection='3d')
        else:
            ax3 = fig.add_subplot(111, projection='3d')
            fig.subplots_adjust(left=0.02, right=0.98, top=0.90, bottom=0.08)
        self.fig, self.scene = fig, Scene3D(ax3, arm, data, theme, show_trace=vis.show_trace)
        self.panel_axes, self.cursors = {}, []
        for r, key in enumerate(keys):
            ax = fig.add_subplot(gs[r, 1])
            title, fn = PANELS[key]
            fn(ax, data, theme, True)
            ax.set_title(title, loc='left', fontsize=10 * vis.font_scale)
            if r == len(keys) - 1:
                ax.set_xlabel('time [s]')
            self.cursors.append(ax.axvline(0, color=theme.text, lw=1.0, alpha=0.9))
            self.panel_axes[key] = ax
        fig.suptitle('6-axis retrieval and order-picking cell', color=theme.text, fontsize=14 * vis.font_scale,
                     fontweight='bold', x=0.02, ha='left')
        self.hud = fig.text(0.02, 0.02, '', family=fonts['mono'], fontsize=9.5 * vis.font_scale, color=theme.muted)
        self.hud.set_visible(vis.show_hud)

    # ------------------------------------------------------------------ frame drawing
    def draw(self, i):
        d, th = self.d, self.th
        self.scene.update(i)
        for c in self.cursors:
            c.set_xdata([d.t[i], d.t[i]])
        on = d.suction[i]
        self.hud.set_text(f"t={d.t[i]:6.1f}s   {d.label[i]:<32}  suction={'ON ' if on else 'off'}  load={d.payload_kg[i]:.1f} kg   "
                          f"err={d.ep_mm[i]:5.2f} mm   sigma_min={d.smin[i]:.3f}")
        self.hud.set_color(th.good if on else th.muted)
        return []

    def _indices(self, max_frames):
        n = len(self.d.t)
        stride = max(1, n // max_frames)
        return list(range(0, n, stride)) + [n - 1]

    def _anim(self, max_frames, fps):
        idx = self._indices(max_frames)
        return self.FuncAnimation(self.fig, lambda k: self.draw(idx[k]), frames=len(idx), interval=1000 / fps,
                                  blit=False, repeat=False)

    # ------------------------------------------------------------------ outputs
    def save_video(self, path):
        w = _writer('mp4', self.vis.fps_video)
        if w is None:
            return None
        self._anim(self.vis.max_frames_video, self.vis.fps_video).save(
            str(path), writer=w, dpi=self.vis.dpi_video, savefig_kwargs={'facecolor': self.th.bg})
        return path.name

    def save_gif(self, path):
        self._anim(self.vis.max_frames_gif, self.vis.fps_gif).save(
            str(path), writer=_writer('gif', self.vis.fps_gif), dpi=self.vis.dpi_gif, savefig_kwargs={'facecolor': self.th.bg})
        return path.name

    def save_png_last(self, path, dpi):
        self.draw(len(self.d.t) - 1)
        self.fig.savefig(path, dpi=dpi, facecolor=self.th.bg)
        return path.name

    # ------------------------------------------------------------------ interactive window (--show only)
    def show(self):
        """Open the window with check-boxes to switch things on/off while it plays."""
        from matplotlib.widgets import CheckButtons
        th, plt = self.th, self.plt
        labels = [f'panel: {k}' for k in self.panel_axes] + ['TCP trail', 'status strip']
        state = [ax.get_visible() for ax in self.panel_axes.values()] + [self.scene.trace.get_visible(), self.hud.get_visible()]
        box = self.fig.add_axes([0.80, 0.005, 0.19, 0.012 * (len(labels) + 1) + 0.03], facecolor=th.panel)
        for s in box.spines.values():
            s.set_edgecolor(th.grid)
        chk = CheckButtons(box, labels, state)
        for lab in chk.labels:
            lab.set_color(th.text); lab.set_fontsize(8 * self.vis.font_scale)
        keys = list(self.panel_axes)

        def toggled(label):
            i = labels.index(label)
            if i < len(keys):
                ax = self.panel_axes[keys[i]]
                ax.set_visible(not ax.get_visible())
            elif label == 'TCP trail':
                self.scene.trace.set_visible(not self.scene.trace.get_visible())
            else:
                self.hud.set_visible(not self.hud.get_visible())
            self.fig.canvas.draw_idle()

        chk.on_clicked(toggled)
        self._keep = (chk, self._anim(self.vis.max_frames_video, self.vis.fps_video))   # keep references alive
        plt.show()
