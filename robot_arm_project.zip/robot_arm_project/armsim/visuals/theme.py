"""
theme.py -- ALL colours and fonts for every image, graph and video. Change the look here and nowhere else.

    th = get_theme('dark')                 # or 'light'
    apply_theme(th, font='', scale=1.0)    # sets matplotlib defaults (call once before drawing)

To make your own theme: copy DARK below, rename it, change colours, add it to THEMES.
Colours are plain hex strings. `series` is the colour cycle used for the 6 joints.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Theme:
    name: str
    bg: str            # figure background
    panel: str         # graph / 3D background
    text: str          # normal text
    muted: str         # secondary text, ticks
    grid: str          # grid lines, axis frame
    series: tuple      # 6 colours (joints q1..q6)
    accent: str        # main highlight (TCP, cursor)
    good: str          # suction ON / success
    bad: str           # errors / unreachable
    warn: str          # warnings / thresholds
    arm_link: str      # robot links
    arm_joint: str     # robot joints
    shelf: str         # shelf bins
    tote: str          # order tote
    floor: str         # floor grid
    items: tuple       # cube colours (one per item, repeats if more items)
    fonts_sans: tuple  # tried in order, first installed one wins
    fonts_mono: tuple  # same, for the status strip


DARK = Theme(
    name='dark', bg='#0d1117', panel='#161b22', text='#e6edf3', muted='#8b949e', grid='#30363d',
    series=('#58a6ff', '#f0883e', '#3fb950', '#bc8cff', '#d29922', '#ff7b72'),
    accent='#58a6ff', good='#3fb950', bad='#f85149', warn='#d29922',
    arm_link='#e6edf3', arm_joint='#79c0ff', shelf='#6e7681', tote='#3fb950', floor='#21262d',
    items=('#f0883e', '#bc8cff', '#d29922', '#ff7b72', '#39d0d8', '#e3b341', '#db61a2', '#a5d6ff'),
    fonts_sans=('Segoe UI', 'Inter', 'Helvetica Neue', 'Arial', 'DejaVu Sans'),
    fonts_mono=('Cascadia Mono', 'Consolas', 'JetBrains Mono', 'DejaVu Sans Mono'),
)

LIGHT = Theme(
    name='light', bg='#ffffff', panel='#f6f8fa', text='#1f2328', muted='#656d76', grid='#d0d7de',
    series=('#0969da', '#bc4c00', '#1a7f37', '#8250df', '#9a6700', '#cf222e'),
    accent='#0969da', good='#1a7f37', bad='#cf222e', warn='#9a6700',
    arm_link='#1f2328', arm_joint='#0969da', shelf='#8c959f', tote='#1a7f37', floor='#eaeef2',
    items=('#bc4c00', '#8250df', '#9a6700', '#cf222e', '#0a7e8c', '#7d4e00', '#bf3989', '#0550ae'),
    fonts_sans=('Segoe UI', 'Inter', 'Helvetica Neue', 'Arial', 'DejaVu Sans'),
    fonts_mono=('Cascadia Mono', 'Consolas', 'JetBrains Mono', 'DejaVu Sans Mono'),
)

THEMES = {'dark': DARK, 'light': LIGHT}


def get_theme(name: str) -> Theme:
    if name not in THEMES:
        raise ValueError(f"unknown theme '{name}'. Available: {', '.join(THEMES)}")
    return THEMES[name]


def pick_font(candidates, forced=''):
    """First installed font from `candidates` (or `forced` when given and installed)."""
    from matplotlib import font_manager
    installed = {f.name for f in font_manager.fontManager.ttflist}
    for name in ([forced] if forced else []) + list(candidates):
        if name in installed:
            return name
    return 'DejaVu Sans'


def apply_theme(th: Theme, font: str = '', scale: float = 1.0):
    """Set matplotlib's global defaults from the theme. Returns {'sans': name, 'mono': name} actually used."""
    import matplotlib as mpl
    from cycler import cycler
    sans = pick_font(th.fonts_sans, font)
    mono = pick_font(th.fonts_mono)
    base = 10 * scale
    mpl.rcParams.update({
        'figure.facecolor': th.bg, 'savefig.facecolor': th.bg, 'savefig.edgecolor': th.bg,
        'axes.facecolor': th.panel, 'axes.edgecolor': th.grid, 'axes.labelcolor': th.text,
        'axes.titlecolor': th.text, 'axes.titleweight': 'bold', 'axes.titlesize': base * 1.15,
        'axes.labelsize': base, 'axes.grid': True, 'axes.axisbelow': True,
        'axes.spines.top': False, 'axes.spines.right': False,
        'axes.prop_cycle': cycler(color=list(th.series)),
        'grid.color': th.grid, 'grid.alpha': 0.7, 'grid.linewidth': 0.6,
        'xtick.color': th.muted, 'ytick.color': th.muted, 'xtick.labelsize': base * 0.9, 'ytick.labelsize': base * 0.9,
        'text.color': th.text, 'font.family': sans, 'font.size': base,
        'legend.facecolor': th.panel, 'legend.edgecolor': th.grid, 'legend.labelcolor': th.text,
        'legend.fontsize': base * 0.85, 'legend.framealpha': 0.9,
        'lines.linewidth': 1.4,
    })
    return {'sans': sans, 'mono': mono}
