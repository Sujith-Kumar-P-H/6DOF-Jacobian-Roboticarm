"""
panels.py -- the REGISTRY of graphs. One function = one graph.

HOW TO ADD A NEW GRAPH (3 steps)
  1. write a function below with the decorator  @panel('mykey', 'Title')   and the signature (ax, d, th, compact)
        ax       the matplotlib axes to draw on
        d        RunData (recorder.py): d.t, d.q, d.ep_mm, d.smin, ...
        th       Theme (theme.py): use th.series, th.accent, th.warn ... never hard-code colours
        compact  True in the video side column (small), False in the stand-alone PNG (big: add legends / axis labels)
  2. it is now available as   --panels joints,mykey
  3. optional: to also get a stand-alone PNG, add a line to FIGURES in figures.py

The video draws a moving cursor line on every panel automatically.
"""
from __future__ import annotations

import numpy as np

PANELS = {}            # key -> (title, function)


def panel(key, title):
    def deco(fn):
        PANELS[key] = (title, fn)
        return fn
    return deco


def _xlabel(ax, compact):
    if not compact:
        ax.set_xlabel('time [s]')


@panel('joints', 'Joint angles [deg]')
def joints(ax, d, th, compact):
    for i in range(6):
        ax.plot(d.t, np.degrees(d.q[:, i]), color=th.series[i], lw=1.0 if compact else 1.4, label=f'q{i+1}')
    if not compact:
        ax.set_ylabel('joint angle [deg]')
        ax.legend(ncol=6, loc='upper center', bbox_to_anchor=(0.5, 1.0))
    _xlabel(ax, compact)


@panel('error', 'Task position error [mm]')
def error(ax, d, th, compact):
    ax.plot(d.t, d.ep_mm, color=th.bad)
    ax.fill_between(d.t, 0, d.ep_mm, color=th.bad, alpha=0.15)
    if not compact:
        ax.set_ylabel('position error [mm]')
    _xlabel(ax, compact)


@panel('orient', 'Task orientation error [deg]')
def orient(ax, d, th, compact):
    ax.plot(d.t, d.eo_deg, color=th.series[3])
    ax.fill_between(d.t, 0, d.eo_deg, color=th.series[3], alpha=0.15)
    if not compact:
        ax.set_ylabel('orientation error [deg]')
    _xlabel(ax, compact)


@panel('manip', 'Singularity margin  sigma_min(J)')
def manip(ax, d, th, compact):
    ax.plot(d.t, d.smin, color=th.series[1])
    ax.axhline(0.06, ls='--', lw=0.9, color=th.warn, label='DLS damping starts')
    if not compact:
        ax.set_ylabel('sigma_min(J)')
        ax.legend(loc='upper right')
    _xlabel(ax, compact)


@panel('manip_w', 'Manipulability  w = sqrt(det(J J^T))')
def manip_w(ax, d, th, compact):
    ax.semilogy(d.t, np.maximum(d.w, 1e-12), color=th.accent)
    ax.grid(True, which='both')
    if not compact:
        ax.set_ylabel('w  (log scale)')
    _xlabel(ax, compact)


@panel('velocity', 'Joint speed [deg/s]')
def velocity(ax, d, th, compact):
    for i in range(6):
        ax.plot(d.t, np.degrees(d.qd[:, i]), color=th.series[i], lw=0.9, label=f'q{i+1}')
    if not compact:
        ax.set_ylabel('joint speed [deg/s]')
        ax.legend(ncol=6, loc='upper center')
    _xlabel(ax, compact)


@panel('speed', 'TCP speed [m/s]')
def speed(ax, d, th, compact):
    ax.plot(d.t, d.speed, color=th.good)
    if not compact:
        ax.set_ylabel('tool speed [m/s]')
    _xlabel(ax, compact)


@panel('payload', 'Payload carried [kg]')
def payload(ax, d, th, compact):
    from ..config import ROBOT
    ax.fill_between(d.t, 0, d.payload_kg, step='post', color=th.good, alpha=0.35)
    ax.step(d.t, d.payload_kg, where='post', color=th.good)
    lim = ROBOT.item_payload_limit_kg
    ax.axhline(lim, ls='--', lw=0.9, color=th.bad, label=f'max payload {lim:.1f} kg')
    ax.set_ylim(0, lim * 1.15)
    if compact:
        ax.legend(loc='upper right', fontsize=7)
    else:
        ax.set_ylabel('mass carried [kg]')
        ax.legend(loc='upper right')
    _xlabel(ax, compact)
