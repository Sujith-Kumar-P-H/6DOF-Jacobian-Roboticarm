"""
figures.py -- the still PNG images.

FIGURES maps  file name -> list of panel keys (panels.py), stacked vertically with a shared time axis.
To get a new image, add one line here.
"""
from __future__ import annotations

from .panels import PANELS
from .scene3d import Scene3D

FIGURES = {
    'joint_angles.png': ['joints'],
    'tracking_error.png': ['error', 'orient'],
    'jacobian_singularity.png': ['manip_w', 'manip'],
    'joint_speeds.png': ['velocity', 'speed'],
    'payload.png': ['payload'],
}


def save_panel_figures(plt, d, th, out_dir, dpi):
    """Every entry of FIGURES -> one PNG. Returns the list of file names."""
    saved = []
    for fname, keys in FIGURES.items():
        fig, axs = plt.subplots(len(keys), 1, figsize=(9, 3.2 * len(keys) + 0.6), sharex=True, squeeze=False)
        for ax, key in zip(axs[:, 0], keys):
            title, fn = PANELS[key]
            fn(ax, d, th, False)
            ax.set_title(title, loc='left')
        axs[-1, 0].set_xlabel('time [s]')
        fig.tight_layout()
        fig.savefig(out_dir / fname, dpi=dpi, facecolor=th.bg)
        plt.close(fig)
        saved.append(fname)
    return saved


def save_scene_figures(plt, arm, d, th, out_dir, dpi, show_trace=True):
    """tcp_path_3d.png (whole TCP path) and final_scene.png (last frame)."""
    saved = []
    fig = plt.figure(figsize=(8, 7))
    ax = fig.add_subplot(111, projection='3d')
    sc = Scene3D(ax, arm, d, th, show_trace=False)
    ax.plot(d.p[:, 0], d.p[:, 1], d.p[:, 2], color=th.accent, lw=1.3, label='TCP path')
    ax.set_title('TCP path: home -> shelf bins -> tote -> home', color=th.text)
    ax.legend(loc='upper left')
    fig.tight_layout()
    fig.savefig(out_dir / 'tcp_path_3d.png', dpi=dpi, facecolor=th.bg)
    plt.close(fig)
    saved.append('tcp_path_3d.png')

    fig = plt.figure(figsize=(8, 7))
    ax = fig.add_subplot(111, projection='3d')
    sc = Scene3D(ax, arm, d, th, show_trace=show_trace)
    sc.update(len(d.t) - 1)
    ax.set_title('Final scene', color=th.text)
    fig.tight_layout()
    fig.savefig(out_dir / 'final_scene.png', dpi=dpi, facecolor=th.bg)
    plt.close(fig)
    saved.append('final_scene.png')
    return saved
