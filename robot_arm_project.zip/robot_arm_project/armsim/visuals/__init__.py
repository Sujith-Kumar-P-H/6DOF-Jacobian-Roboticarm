"""
visuals -- everything that draws. Nothing in here changes how the robot behaves.

    theme.py       colours + fonts (dark / light)         <- change the LOOK here
    panels.py      registry of graphs (one function each) <- add a GRAPH here
    scene3d.py     the 3D workcell picture
    figures.py     still PNG images
    animation.py   video, GIF, interactive window

Entry point used by pick_place_robot.py:   render_all(arm, data, vis, out_dir)
"""
from __future__ import annotations

from pathlib import Path


def render_all(arm, data, vis, out_dir):
    """Save the requested images/video/GIF into out_dir. Open a window ONLY if vis.show_window is True.
    Returns the list of saved file names."""
    import matplotlib
    if not vis.show_window:
        matplotlib.use('Agg')                 # no window, files only (must be chosen before pyplot is imported)
    import matplotlib.pyplot as plt
    from .animation import Animation
    from .figures import save_panel_figures, save_scene_figures
    from .theme import apply_theme, get_theme

    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    th = get_theme(vis.theme)
    fonts = apply_theme(th, vis.font, vis.font_scale)
    saved = []

    if 'png' in vis.formats:
        saved += save_panel_figures(plt, data, th, out_dir, vis.dpi_png)
        saved += save_scene_figures(plt, arm, data, th, out_dir, vis.dpi_png, vis.show_trace)

    anim = Animation(plt, arm, data, th, vis, fonts)
    if 'png' in vis.formats:
        saved.append(anim.save_png_last(out_dir / 'dashboard_final.png', vis.dpi_png))
    if 'mp4' in vis.formats:
        name = anim.save_video(out_dir / 'arm6_picking.mp4')
        if name:
            saved.append(name)
        else:
            print('  (mp4 skipped: ffmpeg not found. Run: pip install imageio-ffmpeg)')
    if 'gif' in vis.formats:
        saved.append(anim.save_gif(out_dir / 'arm6_picking.gif'))
    if vis.show_window:
        anim.show()
    plt.close('all')
    return saved
