"""
scene3d.py -- the 3D picture of the workcell (shelf, tote, robot, items). Used by the video AND the still images.

    scene = Scene3D(ax, arm, data, theme, show_trace=True)
    scene.update(i)        # pose the robot / items / trail for sample number i

To change how the robot or the shelf LOOKS, edit this file. Colours come from the theme.
"""
from __future__ import annotations

import numpy as np

from ..config import ITEM_SIZE, SHELVES, TOTE_CENTER, TOTE_FLOOR_Z

VIEW_LIMITS = dict(x=(-1.0, 1.0), y=(-0.7, 0.5), z=(0.0, 1.3))


def cube_edges(center, R, size=ITEM_SIZE):
    """12 cube edges as one NaN-separated polyline."""
    h = size / 2
    c = np.array([[sx, sy, sz] for sx in (-h, h) for sy in (-h, h) for sz in (-h, h)])
    pts = c @ R.T + center
    idx = [(0, 1), (2, 3), (4, 5), (6, 7), (0, 2), (1, 3), (4, 6), (5, 7), (0, 4), (1, 5), (2, 6), (3, 7)]
    out = []
    for a, b in idx:
        out += [pts[a], pts[b], [np.nan] * 3]
    return np.array(out)


def style_axes3d(ax, th, labels=True):
    """Dark/light styling for a 3D axes (panes, grid, ticks)."""
    ax.set_facecolor(th.bg)
    for axis in (ax.xaxis, ax.yaxis, ax.zaxis):
        try:
            axis.set_pane_color(_rgba(th.panel, 0.0 if th.name == 'dark' else 0.5))
            axis._axinfo['grid']['color'] = th.grid
            axis._axinfo['grid']['linewidth'] = 0.5
            axis.line.set_color(th.grid)
        except Exception:                      # private matplotlib attributes can change between versions
            pass
    ax.tick_params(colors=th.muted, labelsize=8)
    if labels:
        ax.set_xlabel('x [m]', color=th.muted); ax.set_ylabel('y [m]', color=th.muted); ax.set_zlabel('z [m]', color=th.muted)
    ax.set_xlim(*VIEW_LIMITS['x']); ax.set_ylim(*VIEW_LIMITS['y']); ax.set_zlim(*VIEW_LIMITS['z'])
    ax.set_box_aspect((2.0, 1.2, 1.3))


def _rgba(hex_color, alpha):
    h = hex_color.lstrip('#')
    return tuple(int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)) + (alpha,)


def draw_workcell(ax, th):
    """Static things: floor grid, every shelf (unreachable top level in the 'bad' colour), the tote."""
    vx, vy = VIEW_LIMITS['x'], VIEW_LIMITS['y']
    for gx in np.linspace(vx[0], vx[1], 9):
        ax.plot([gx, gx], list(vy), [0, 0], color=th.floor, lw=0.7)
    for gy in np.linspace(vy[0], vy[1], 7):
        ax.plot(list(vx), [gy, gy], [0, 0], color=th.floor, lw=0.7)
    for sh in SHELVES:
        base, ap, lat = np.array([*sh.front, 0.0]), np.array(sh.approach), np.array(sh.lateral)
        for lv, z in enumerate(sh.level_z):
            for off in sh.col_offsets:
                col = th.bad if lv == len(sh.level_z) - 1 else th.shelf
                def pt(s_, l_, dz):                     # s_ along approach, l_ along lateral, dz height
                    return base + ap * s_ + lat * (off + l_) + np.array([0, 0, z + dz])
                ring = [pt(-0.02, -0.09, 0), pt(0.20, -0.09, 0), pt(0.20, 0.09, 0), pt(-0.02, 0.09, 0), pt(-0.02, -0.09, 0)]
                for dz in (-0.07, 0.07):
                    r = np.array([c + np.array([0, 0, dz]) for c in ring])
                    ax.plot(r[:, 0], r[:, 1], r[:, 2], color=col, lw=0.8)
                for c in ring[:4]:
                    ax.plot([c[0]] * 2, [c[1]] * 2, [z - 0.07, z + 0.07], color=col, lw=0.8)
    cx, cy = TOTE_CENTER
    ax.plot([cx - .15, cx + .15, cx + .15, cx - .15, cx - .15], [cy - .12, cy - .12, cy + .12, cy + .12, cy - .12],
            [TOTE_FLOOR_Z] * 5, color=th.tote, lw=2)


class Scene3D:
    def __init__(self, ax, arm, data, theme, show_trace=True):
        self.ax, self.arm, self.d, self.th = ax, arm, data, theme
        style_axes3d(ax, theme)
        draw_workcell(ax, theme)
        n_items = len(data.items[0]) if data.items else 0
        self.links, = ax.plot([], [], [], '-', color=theme.arm_link, lw=4, solid_capstyle='round')
        self.joints, = ax.plot([], [], [], 'o', color=theme.arm_joint, ms=5)
        self.tcp, = ax.plot([], [], [], 'o', ms=9, color=theme.accent, mec=theme.text, mew=0.8)
        self.trace, = ax.plot([], [], [], color=theme.accent, lw=1, alpha=0.55)
        self.trace.set_visible(show_trace)
        self.cubes = [ax.plot([], [], [], color=theme.items[i % len(theme.items)], lw=2)[0] for i in range(n_items)]

    def update(self, i):
        pts = self.arm.link_points(self.d.q[i])
        self.links.set_data_3d(pts[:, 0], pts[:, 1], pts[:, 2])
        self.joints.set_data_3d(pts[1:-1, 0], pts[1:-1, 1], pts[1:-1, 2])
        self.tcp.set_data_3d([pts[-1, 0]], [pts[-1, 1]], [pts[-1, 2]])
        self.tcp.set_color(self.th.good if self.d.suction[i] else self.th.accent)
        P = self.d.p
        self.trace.set_data_3d(P[:i + 1, 0], P[:i + 1, 1], P[:i + 1, 2])
        for j, (c, R) in enumerate(self.d.items[i]):
            e = cube_edges(c, R)
            self.cubes[j].set_data_3d(e[:, 0], e[:, 1], e[:, 2])
