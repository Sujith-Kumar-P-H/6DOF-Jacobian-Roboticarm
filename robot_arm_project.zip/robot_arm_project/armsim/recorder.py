"""
recorder.py -- the flight recorder. The simulator calls Recorder.record(...) every few steps; the visuals read the result.

    rec = Recorder()
    rec.record(...)             # during simulation
    data = rec.finish()         # -> RunData with ready-to-plot numpy arrays (units already converted for plots)
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class RunData:
    """Everything the plots/video need. Units are plot-friendly (mm, deg)."""
    t: np.ndarray            # time [s]
    q: np.ndarray            # joint angles [rad]              (N, 6)
    qd: np.ndarray           # joint velocities [rad/s]        (N, 6)
    p: np.ndarray            # TCP position [m]                (N, 3)
    ep_mm: np.ndarray        # position tracking error [mm]
    eo_deg: np.ndarray       # orientation tracking error [deg]
    w: np.ndarray            # manipulability
    smin: np.ndarray         # smallest singular value of J
    speed: np.ndarray        # TCP linear speed [m/s]
    payload_kg: np.ndarray   # mass currently carried [kg]
    suction: list            # bool per sample
    label: list              # segment label per sample
    items: list              # per sample: [(pos, R), ...] for every item


class Recorder:
    def __init__(self, log_every=5):
        self.log_every = log_every
        self._n = 0
        self._f = dict(t=[], q=[], qd=[], p=[], ep=[], eo=[], w=[], smin=[], speed=[], payload=[], suction=[], label=[], items=[])

    def record(self, t, q, qd, p, e_p, e_o, w, smin, speed, suction, label, items, payload=0.0):
        """Called once per control step; only every `log_every`-th call is stored."""
        self._n += 1
        if self._n % self.log_every:
            return
        f = self._f
        f['t'].append(t); f['q'].append(q.copy()); f['qd'].append(qd.copy()); f['p'].append(p.copy())
        f['ep'].append(e_p); f['eo'].append(e_o); f['w'].append(w); f['smin'].append(smin); f['speed'].append(speed)
        f['payload'].append(payload); f['suction'].append(suction); f['label'].append(label)
        f['items'].append([(it.pos.copy(), it.R.copy()) for it in items])

    def finish(self) -> RunData:
        f = self._f
        return RunData(t=np.array(f['t']), q=np.array(f['q']), qd=np.array(f['qd']), p=np.array(f['p']),
                       ep_mm=np.array(f['ep']) * 1000, eo_deg=np.degrees(f['eo']), w=np.array(f['w']),
                       smin=np.array(f['smin']), speed=np.array(f['speed']), payload_kg=np.array(f['payload']), suction=f['suction'],
                       label=f['label'], items=f['items'])
