"""
dh_check.py -- "I edited the DH table. Is it still sane?"   Run:   python pick_place_robot.py --check-dh [--dh my_table.json]

It does NOT change anything. It prints the table, checks it, and tells you what your edit does to the mission:
  * units / typo sanity (metres, radians, finite numbers)
  * forward kinematics valid (orthonormal rotation), analytic Jacobian == finite-difference Jacobian
  * where the tool ends up at the zero pose and at the HOME posture
  * can the arm still reach every shelf / tote pose of the mission?  (which orders would be SKIPPED)
  * how the table differs from the factory (UR5-style) table
"""
from __future__ import annotations

import math

import numpy as np

from .config import (DEFAULT_ORDERS, FLOOR_CLEARANCE_M, HOME_Q, ROBOT, UR5_STANDARD, DHTable, RobotSpec)
from .kinematics import Arm6
from .mission import check_reachable
from .workcell import cycle_key_poses, make_items

FACTORY_EXPECTED = {'A': 'OK', 'B': 'OK', 'C': 'OK', 'D': 'SKIPPED', 'E': 'OK', 'F': 'OK', 'G': 'OK', 'H': 'OK'}
# D is on the unreachable top level on purpose. H is reachable (it is rejected for weight, which is not a DH matter).


def check_dh(table: DHTable, base_spec: RobotSpec = ROBOT) -> bool:
    """Print the report. Returns True when there is no hard FAIL."""
    spec = RobotSpec(dh=table, q_lim=base_spec.q_lim, qd_lim=base_spec.qd_lim, tool_len=base_spec.tool_len,
                     base_yaw=base_spec.base_yaw)
    arm = Arm6(spec)
    fails = warns = 0

    def line(level, msg):
        nonlocal fails, warns
        fails += level == 'FAIL'
        warns += level == 'WARN'
        print(f'  [{level}] {msg}')

    print(table.pretty())
    print(f'  base yaw {math.degrees(spec.base_yaw):.0f} deg | tool length {spec.tool_len} m\n')

    # ---- 1. units / typos -------------------------------------------------------------------
    print('1) Units and typos')
    vals = np.concatenate([table.d, table.a, table.alpha, table.theta_offset])
    if not np.all(np.isfinite(vals)):
        line('FAIL', 'a value is NaN/inf')
    else:
        line('PASS', 'all values are finite numbers')
    if np.max(np.abs(np.concatenate([table.d, table.a]))) > 3.0:
        line('WARN', 'a length is larger than 3 m: did you type millimetres instead of metres?')
    else:
        line('PASS', 'lengths look like metres')
    if np.max(np.abs(np.concatenate([table.alpha, table.theta_offset]))) > 2 * math.pi + 1e-9:
        line('WARN', 'an angle is larger than 2*pi: did you type degrees in a radian field? (in Python use math.radians(90); in JSON use alpha_deg)')
    else:
        line('PASS', 'angles look like radians')

    # ---- 2. kinematics consistency ----------------------------------------------------------
    print('\n2) Kinematics consistency')
    rng = np.random.default_rng(0)
    worst_orth, worst_jac = 0.0, 0.0
    for _ in range(100):
        q = rng.uniform(-math.pi, math.pi, 6)
        _, R, J = arm.fk_jac(q)
        worst_orth = max(worst_orth, np.abs(R @ R.T - np.eye(3)).max())
        worst_jac = max(worst_jac, np.abs(J - arm.jacobian_numeric(q)).max())
    line('PASS' if worst_orth < 1e-9 else 'FAIL', f'rotation matrix orthonormal (max error {worst_orth:.1e})')
    line('PASS' if worst_jac < 1e-4 else 'FAIL',
         f'analytic Jacobian == finite-difference Jacobian on 100 random poses (max diff {worst_jac:.1e})')
    if worst_jac >= 1e-4:
        print(f'         hint: is the convention ("{table.convention}") the one your numbers were written for?')

    # ---- 3. where does the tool go ----------------------------------------------------------
    print('\n3) Where the tool is')
    p0, _ = arm.fk(np.zeros(6))
    ph, Rh = arm.fk(HOME_Q)
    line('INFO', f'zero pose (all joints 0): tool at {np.round(p0, 4)} m')
    line('INFO', f'payload rating {spec.max_payload_kg} kg, tool {spec.tool_mass_kg} kg -> max item {spec.item_payload_limit_kg} kg (set in config.RobotSpec; the DH table does not change it)')
    line('INFO', f'HOME posture:            tool at {np.round(ph, 4)} m, tool z-axis {np.round(Rh[:, 2], 3)}')
    pts = arm.link_points(HOME_Q)
    if pts[1:, 2].min() < FLOOR_CLEARANCE_M:
        line('WARN', f'at HOME some link is only {pts[1:, 2].min()*1000:.0f} mm above the floor (limit {FLOOR_CLEARANCE_M*1000:.0f} mm)')
    reach = max(float(np.linalg.norm(arm.fk(rng.uniform(-math.pi, math.pi, 6))[0][:2])) for _ in range(500))
    line('INFO', f'largest horizontal reach found by sampling 500 random poses: {reach:.2f} m (shelves are 0.72 m from the base)')

    # ---- 4. the mission ---------------------------------------------------------------------
    print('\n4) Can the arm still do the mission?   (HOME_Q and the workcell positions in config.py are NOT changed by the DH table)')
    status = {}
    slot = 0
    for it in make_items(DEFAULT_ORDERS):
        ok, why = check_reachable(arm, cycle_key_poses(it, slot).key_poses(), HOME_Q)
        status[it.name] = 'OK' if ok else 'SKIPPED'
        if ok:
            slot += 1
        tag = f'order {it.name} (shelf {it.shelf + 1}, level {it.level}, column {it.col}): '
        if ok:
            line('PASS', tag + 'reachable')
        elif FACTORY_EXPECTED[it.name] == 'SKIPPED':
            line('INFO', tag + f'not reachable, as designed -> {why}')
        else:
            line('WARN', tag + f'would be SKIPPED -> {why}')
    if status != FACTORY_EXPECTED:
        print(f'         factory result is {FACTORY_EXPECTED}; with your table it is {status}.')
        print('         If you changed the robot on purpose: move the shelf (config.py: SHELF_FRONT_X, BIN_Z, BIN_Y, TOTE_CENTER) or HOME_Q to suit it.')

    # ---- 5. difference to factory -----------------------------------------------------------
    print('\n5) Difference from the factory table')
    if table.convention != UR5_STANDARD.convention:
        line('INFO', f'convention is "{table.convention}" (factory is "{UR5_STANDARD.convention}"): numbers are not comparable row by row')
    else:
        diffs = []
        for i, (r, f) in enumerate(zip(table.rows, UR5_STANDARD.rows), 1):
            for nm in ('d', 'a', 'alpha', 'theta_offset'):
                if abs(getattr(r, nm) - getattr(f, nm)) > 1e-12:
                    diffs.append(f'joint {i} {nm}: {getattr(f, nm):.5f} -> {getattr(r, nm):.5f}')
        if diffs:
            for t in diffs:
                line('INFO', t)
        else:
            line('INFO', 'identical to the factory table')

    print(f'\nResult: {fails} FAIL, {warns} WARN.  ' + ('Table is usable.' if not fails else 'Fix the FAIL lines first.'))
    return fails == 0
