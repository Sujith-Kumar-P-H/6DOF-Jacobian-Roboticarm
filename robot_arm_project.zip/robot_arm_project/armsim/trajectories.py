"""
trajectories.py -- motion "segments". A segment answers one question:  "where should the tool be at time t, and how fast?"

Every segment has the same two things, so the controller does not care which kind it is running:
    seg.T               duration [s]
    seg.sample(t)  ->   (p_desired, R_desired, v_desired, w_desired)     position, orientation, linear + angular velocity
    seg.p1, seg.R1      final pose (used to hold still at the end)
    seg.label           text shown in the video

Two kinds:
    CartSegment   straight line in space (used near the shelf, where the path shape matters)
    JointSegment  smooth move in joint space (used for big free-space moves; avoids singularities)
"""
from __future__ import annotations

import numpy as np

from .maths3d import R_to_rotvec, rotvec_to_R, quintic


class CartSegment:
    """Straight line in position and geodesic (SLERP) in orientation, with quintic time scaling.
        p(t) = p0 + s(t/T)(p1 - p0),   R(t) = R0 Exp( s(t/T) * log(R0^T R1) )"""

    def __init__(self, p0, R0, p1, R1, v_lin=0.35, w_ang=1.0, t_min=0.6, label=''):
        self.p0, self.R0, self.p1, self.R1, self.label = p0.copy(), R0.copy(), p1.copy(), R1.copy(), label
        self.phi = R_to_rotvec(R0.T @ R1)
        dist, ang = float(np.linalg.norm(p1 - p0)), float(np.linalg.norm(self.phi))
        self.T = max(t_min, 1.875 * dist / v_lin, 1.875 * ang / w_ang)

    def sample(self, t):
        s, ds = quintic(t / self.T)
        p = self.p0 + s * (self.p1 - self.p0)
        R = self.R0 @ rotvec_to_R(s * self.phi)
        v = ds / self.T * (self.p1 - self.p0)
        w = ds / self.T * (self.R0 @ self.phi)
        return p, R, v, w


class JointSegment:
    """Large free-space move planned in JOINT space (quintic between two joint vectors), then converted into the same
    task-space reference the controller already understands:
        p_d, R_d = FK(q_d(t)),    twist_d = J(q_d) qdot_d      (Jacobian feed-forward)
    The path is checked in advance (41 samples): it must stay away from singularities and above the floor.
    `self.ok` tells the caller whether the check passed."""

    def __init__(self, arm, q0, q1, label='', min_sigma=0.02, min_height=0.02):
        self.arm, self.q0, self.q1, self.label = arm, np.asarray(q0, float), np.asarray(q1, float), label
        dq = np.abs(self.q1 - self.q0)
        self.T = float(max(0.8, np.max(1.875 * dq / (0.6 * arm.qd_lim))))
        self.p1, self.R1 = arm.fk(self.q1)
        self.min_sigma, self.min_z = 1e9, 1e9
        for k in range(41):
            q = self.q0 + quintic(k / 40)[0] * (self.q1 - self.q0)
            self.min_sigma = min(self.min_sigma, arm.manipulability(arm.fk_jac(q)[2])[1])
            self.min_z = min(self.min_z, arm.link_points(q)[1:, 2].min())
        self.ok = self.min_sigma > min_sigma and self.min_z > min_height

    def sample(self, t):
        s, ds = quintic(t / self.T)
        q, qd = self.q0 + s * (self.q1 - self.q0), ds / self.T * (self.q1 - self.q0)
        p, R, J = self.arm.fk_jac(q)
        v = J @ qd
        return p, R, v[:3], v[3:]
