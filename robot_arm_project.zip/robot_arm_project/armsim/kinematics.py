"""
kinematics.py -- the robot's geometry: forward kinematics, Jacobian, inverse kinematics.

The ONLY input that defines the robot is a RobotSpec (config.py), which contains the DH table.
Change the DH table -> everything computed here (and everything built on top of it) changes.

    arm = Arm6()                    # uses config.ROBOT
    arm = Arm6(RobotSpec(dh=my_table))
    p, R   = arm.fk(q)              # tool-centre-point position (3,) and orientation (3,3)
    p, R, J = arm.fk_jac(q)         # plus the 6x6 geometric Jacobian
    q, ok, pos_err, ang_err = arm.ik(p_d, R_d, q_seed)
"""
from __future__ import annotations

import math

import numpy as np

from .config import ROBOT, RobotSpec
from .maths3d import R_to_rotvec


class Arm6:
    """6R arm described by a DH table plus a suction-cup tool.

    STANDARD DH:   A_i = Rz(theta) Tz(d) Tx(a) Rx(alpha)
    MODIFIED DH:   A_i = Rx(alpha) Tx(a) Rz(theta) Tz(d)
    theta = q_i + theta_offset_i.   T_0^6 = Base * A1 A2 ... A6, then the fixed tool transform Tz(tool_len) gives the TCP.

    GEOMETRIC JACOBIAN (6x6, joint rates -> [linear velocity; angular velocity] of the TCP, in the base frame):
        for revolute joint i with axis z and origin o:     Jv_i = z x (p_tcp - o)        Jw_i = z
    Where the joint axis lives depends on the convention:
        standard DH : joint i turns about z of frame i-1
        modified DH : joint i turns about z of frame i
    """

    def __init__(self, spec: RobotSpec = ROBOT):
        self.spec = spec
        self.dh = spec.dh
        self.q_lim, self.qd_lim = spec.q_lim, spec.qd_lim
        self.tool_len, self.base_yaw = spec.tool_len, spec.base_yaw
        self.d, self.a, self.alpha, self.th0 = self.dh.d, self.dh.a, self.dh.alpha, self.dh.theta_offset
        self._modified = self.dh.convention == 'modified'

    # ------------------------------------------------------------------ one DH link transform
    @staticmethod
    def dh_standard(theta, d, a, alpha):
        ct, st, ca, sa = math.cos(theta), math.sin(theta), math.cos(alpha), math.sin(alpha)
        return np.array([[ct, -st * ca, st * sa, a * ct],
                         [st, ct * ca, -ct * sa, a * st],
                         [0.0, sa, ca, d],
                         [0.0, 0.0, 0.0, 1.0]])

    @staticmethod
    def dh_modified(theta, d, a, alpha):
        ct, st, ca, sa = math.cos(theta), math.sin(theta), math.cos(alpha), math.sin(alpha)
        return np.array([[ct, -st, 0.0, a],
                         [st * ca, ct * ca, -sa, -sa * d],
                         [st * sa, ct * sa, ca, ca * d],
                         [0.0, 0.0, 0.0, 1.0]])

    # ------------------------------------------------------------------ forward kinematics
    def frames(self, q):
        """List of 8 matrices: [base, frame1, ..., frame6, TCP]. Index 7 is the TCP."""
        c, s_ = math.cos(self.base_yaw), math.sin(self.base_yaw)
        T = np.array([[c, -s_, 0, 0], [s_, c, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1.0]])
        link = self.dh_modified if self._modified else self.dh_standard
        out = [T.copy()]
        for i in range(6):
            T = T @ link(q[i] + self.th0[i], self.d[i], self.a[i], self.alpha[i])
            out.append(T.copy())
        Ttool = np.eye(4)
        Ttool[2, 3] = self.tool_len
        out.append(T @ Ttool)
        return out

    def fk(self, q):
        """TCP position (3,) and rotation matrix (3,3) in the base frame."""
        T = self.frames(q)[-1]
        return T[:3, 3].copy(), T[:3, :3].copy()

    def fk_jac(self, q):
        """FK plus geometric Jacobian in one pass. Returns p, R, J(6x6)."""
        Fs = self.frames(q)
        p = Fs[-1][:3, 3]
        shift = 1 if self._modified else 0              # which frame carries joint i's axis
        J = np.zeros((6, 6))
        for i in range(6):
            z, o = Fs[i + shift][:3, 2], Fs[i + shift][:3, 3]
            J[:3, i] = np.cross(z, p - o)
            J[3:, i] = z
        return p.copy(), Fs[-1][:3, :3].copy(), J

    def jacobian_numeric(self, q, eps=1e-6):
        """Finite-difference Jacobian used ONLY to validate the analytic one."""
        p0, R0 = self.fk(q)
        J = np.zeros((6, 6))
        for i in range(6):
            dq = np.zeros(6)
            dq[i] = eps
            p1, R1 = self.fk(q + dq)
            J[:3, i] = (p1 - p0) / eps
            J[3:, i] = R_to_rotvec(R1 @ R0.T) / eps
        return J

    # ------------------------------------------------------------------ Jacobian tools
    @staticmethod
    def manipulability(J):
        """Yoshikawa w = sqrt(det(J J^T)) = product of singular values, and sigma_min (distance to singularity)."""
        s = np.linalg.svd(J, compute_uv=False)
        return float(np.prod(s)), float(s[-1])

    @staticmethod
    def dls_pinv(J, lam0=0.06, eps=0.06):
        """Damped least-squares pseudo-inverse J^T (J J^T + lam^2 I)^-1 with variable damping:
        lam^2 = lam0^2 (1 - (sigma_min/eps)^2) when sigma_min < eps, else 0."""
        smin = np.linalg.svd(J, compute_uv=False)[-1]
        lam2 = lam0**2 * (1 - (smin / eps) ** 2) if smin < eps else 0.0
        return J.T @ np.linalg.inv(J @ J.T + lam2 * np.eye(6) + 1e-12 * np.eye(6))

    # ------------------------------------------------------------------ inverse kinematics
    def ik(self, p_d, R_d, q0, tol_p=1e-5, tol_o=1e-4, max_iter=300):
        """Iterative numerical IK: q <- q + J^+ e, started from q0 so the solution stays in the same arm configuration.
        Returns (q, ok, position_residual [m], orientation_residual [rad])."""
        q = np.array(q0, float)
        for _ in range(max_iter):
            p, R, J = self.fk_jac(q)
            e = np.concatenate([p_d - p, R_to_rotvec(R_d @ R.T)])
            if np.linalg.norm(e[:3]) < tol_p and np.linalg.norm(e[3:]) < tol_o:
                return q, bool(np.all(np.abs(q) <= self.q_lim)), np.linalg.norm(e[:3]), np.linalg.norm(e[3:])
            dq = self.dls_pinv(J, lam0=0.03, eps=0.03) @ e
            n = np.max(np.abs(dq))
            if n > 0.5:
                dq *= 0.5 / n
            q = q + dq
        p, R = self.fk(q)
        ep, eo = np.linalg.norm(p_d - p), np.linalg.norm(R_to_rotvec(R_d @ R.T))
        return q, False, ep, eo

    def link_points(self, q):
        """Joint origins + TCP (8 points) for drawing and the floor-collision check."""
        return np.array([F[:3, 3] for F in self.frames(q)])
