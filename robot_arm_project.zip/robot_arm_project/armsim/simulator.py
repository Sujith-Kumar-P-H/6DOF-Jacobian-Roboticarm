"""
simulator.py -- the MOTION layer: runs the control loops and moves the robot through segments.

It knows how to move (step, run a segment, dwell, go to a pose). It does NOT know what a "mission" is -- that is
mission.py. Think of it as the robot + its controller; the mission is the operator giving it orders.

    sim = Simulator(arm, items, rng, slip_prob)
    sim.goto(p, R, 'label')            straight-line move
    sim.goto_joint(p, R, 'label')      joint-space move (big free-space moves)
    sim.dwell(0.4)                     stand still for 0.4 s with the loop still running
    sim.events                         list of (time, message) for the report
    sim.recorder.finish()              plots/video data
"""
from __future__ import annotations

import math

import numpy as np

from .config import EXTRA_IK_SEEDS, FAULT_TRACKING_ERROR_M, GAINS, HOME_Q
from .controller import ClikController, JointServo
from .gripper import SuctionGripper
from .kinematics import Arm6
from .recorder import Recorder
from .trajectories import CartSegment, JointSegment


class Simulator:
    def __init__(self, arm: Arm6, items, rng, slip_prob=0.2, gains=GAINS, log_every=5):
        self.arm, self.items, self.dt = arm, items, gains.dt
        self.clik = ClikController(arm, gains)
        self.q = HOME_Q.copy()                       # robot state: joint angles ...
        self.qd = np.zeros(6)                        # ... and joint velocities
        self.servo = JointServo(arm, self.q, gains)
        self.gripper = SuctionGripper(rng, slip_prob)
        self.recorder = Recorder(log_every)
        self.t, self.step_n = 0.0, 0
        self.fault = False
        self.events = []                             # (time, text)
        self.cur_label = 'home'
        self.p_ref, self.R_ref = arm.fk(self.q)      # pose to hold when dwelling

    # ------------------------------------------------------------------ one control + physics step
    def step(self, p_d, R_d, v_d, w_d):
        qd_cmd, e_p, e_o, J, p = self.clik.command(self.q, p_d, R_d, v_d, w_d)     # outer loop
        self.q, self.qd = self.servo.update(self.q, self.qd, qd_cmd)                # inner loop + joint physics
        self.t += self.dt
        self.step_n += 1
        self.p_ref, self.R_ref = p_d, R_d
        if self.gripper.held is not None:
            pn, Rn = self.arm.fk(self.q)
            self.gripper.carry(pn, Rn)
        w, smin = self.arm.manipulability(J)
        self.recorder.record(self.t, self.q, self.qd, p, float(np.linalg.norm(e_p)), float(np.linalg.norm(e_o)), w, smin,
                             float(np.linalg.norm((J @ self.qd)[:3])), self.gripper.on, self.cur_label, self.items,
                             self.gripper.held.mass_kg if self.gripper.held is not None else 0.0)
        return float(np.linalg.norm(e_p)), float(np.linalg.norm(e_o))

    # ------------------------------------------------------------------ motions
    def run_segment(self, seg):
        """Execute one segment, then hold the end pose until the loop has converged. False on a tracking fault."""
        self.cur_label = seg.label
        n = int(math.ceil(seg.T / self.dt))
        for k in range(n + 1):
            p, R, v, w = seg.sample(k * self.dt)
            ep, eo = self.step(p, R, v, w)
            if ep > FAULT_TRACKING_ERROR_M:                          # rule-based safety stop
                self.fault = True
                self.events.append((self.t, f'FAULT: tracking error {ep*1000:.0f} mm in segment "{seg.label}"'))
                return False
        for k in range(int(1.5 / self.dt)):                          # settle (max 1.5 s)
            ep, eo = self.step(seg.p1, seg.R1, np.zeros(3), np.zeros(3))
            if ep < 5e-4 and eo < 2e-3 and np.max(np.abs(self.qd)) < 5e-3 and k > 25:
                break
        return True

    def dwell(self, duration):
        for _ in range(int(duration / self.dt)):
            self.step(self.p_ref, self.R_ref, np.zeros(3), np.zeros(3))

    def goto(self, p1, R1, label, v_lin=0.35, w_ang=1.0):
        """Straight-line Cartesian move."""
        p0, R0 = self.arm.fk(self.q)
        return self.run_segment(CartSegment(p0, R0, p1, R1, v_lin, w_ang, label=label))

    def goto_joint(self, p1, R1, label):
        """Free-space move: IK for the goal posture, then a joint-space path. Tries two IK seeds."""
        for seed in (self.q, HOME_Q, *EXTRA_IK_SEEDS):
            q1, ok, _, _ = self.arm.ik(p1, R1, seed)
            if ok:
                seg = JointSegment(self.arm, self.q, q1, label)
                if seg.ok:
                    return self.run_segment(seg)
        self.fault = True
        self.events.append((self.t, f'FAULT: no safe joint-space path for "{label}"'))
        return False

    def go_home(self):
        return self.run_segment(JointSegment(self.arm, self.q, HOME_Q, 'return HOME'))
