"""
gripper.py -- the suction cup: seal rule, vacuum measurement, hold/release.

Rule: the cup seals only when it is within SEAL_MAX_LATERAL / SEAL_MAX_DEPTH of the item face and within
SEAL_MAX_ANGLE_DEG of its normal -- and a random leak (probability `slip`) did not happen. The vacuum is then MEASURED
(sealed ~ -62 kPa, leaking ~ -4 kPa) and compared with a threshold: this is the verification step.
"""
from __future__ import annotations

import math

import numpy as np

from .config import (ITEM_SIZE, SEAL_MAX_ANGLE_DEG, SEAL_MAX_DEPTH, SEAL_MAX_LATERAL, VACUUM_LEAK_KPA,
                     VACUUM_OK_THRESHOLD_KPA, VACUUM_SEALED_KPA)
from .maths3d import R_to_rotvec
from .workcell import Item


class SuctionGripper:
    def __init__(self, rng, slip_prob):
        self.rng, self.slip = rng, slip_prob
        self.on = False
        self.vacuum = 0.0                    # kPa (negative = suction)
        self.held = None                     # Item or None
        self.held_off = np.zeros(3)          # item centre offset in the TCP frame

    def engage(self, item: Item, tcp_p, tcp_R, dwell):
        """Try to grip `item`. `dwell(seconds)` lets the simulator keep running while the vacuum builds up.
        Returns (verified, lateral_err, depth_err, angle_err_deg)."""
        R_tool = item.tool_R                                  # tool orientation for this item's shelf
        face_p = item.pos - R_tool[:, 2] * ITEM_SIZE / 2
        err = face_p - tcp_p
        lateral = float(np.linalg.norm(err[1:]))
        depth = abs(float(err[0]))
        ang = math.degrees(np.linalg.norm(R_to_rotvec(R_tool @ tcp_R.T)))
        # NOTE: the random draw only happens when the geometry is already good (keeps results reproducible per seed)
        seal = lateral <= SEAL_MAX_LATERAL and depth <= SEAL_MAX_DEPTH and ang <= SEAL_MAX_ANGLE_DEG \
            and self.rng.random() >= self.slip
        self.on = True
        dwell(0.4)
        self.vacuum = VACUUM_SEALED_KPA + self.rng.normal(0, 1.5) if seal else VACUUM_LEAK_KPA + self.rng.normal(0, 1.0)
        if seal:
            self.held = item
            self.held_off = tcp_R.T @ (item.pos - tcp_p)
            item.state = 'held'
        return self.vacuum < VACUUM_OK_THRESHOLD_KPA, lateral, depth, ang

    def abort(self):
        """Switch suction off after a failed grip."""
        self.on = False

    def release(self, dwell):
        self.on = False
        self.vacuum = 0.0
        if self.held is not None:
            self.held.state = 'placed'
            self.held = None
        dwell(0.3)

    def carry(self, tcp_p, tcp_R):
        """Move the held item with the tool."""
        if self.held is not None:
            self.held.pos, self.held.R = tcp_p + tcp_R @ self.held_off, tcp_R.copy()
