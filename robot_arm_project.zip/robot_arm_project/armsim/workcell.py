"""
workcell.py -- the things in the world around the robot: shelves, stored items, tote slots, key poses.

    Item                one stored cube (name, shelf, level, column, mass) with its live position / state
    shelf_tool_R(i)     tool orientation used to retrieve from shelf i (tool z-axis points into the shelf)
    tote_slot(k)        where the k-th placed item goes inside the tote
    cycle_key_poses()   the 5 poses one pick-and-place cycle must reach (used by the planner AND by the DH checker)

Shelves are described in config.SHELVES. To add a third shelf, add one ShelfSpec there -- nothing here changes.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from .config import (ITEM_MASS_KG, ITEM_SIZE, PRE_PLACE_HEIGHT, SHELVES, STANDOFF, TOTE_CENTER, TOTE_FLOOR_Z,
                     TOTE_STACK_AFTER, TRANSIT_POINT)
from .maths3d import frame_from_zy

R_DOWN = frame_from_zy([0, 0, -1], [0, -1, 0])     # tool points down (placing into the tote)


def shelf_approach(i):
    return np.array(SHELVES[i].approach, float)


def shelf_tool_R(i):
    """Tool orientation for shelf i: the suction axis (tool z) points into the shelf."""
    s = SHELVES[i]
    return frame_from_zy(s.approach, s.y_hint)


R_FWD = shelf_tool_R(0)        # kept for readability / tests: the front shelf


def item_center(shelf_idx, level, col):
    """Centre of the cube stored at (shelf, level, column)."""
    s = SHELVES[shelf_idx]
    base = np.array([s.front[0], s.front[1], 0.0])
    return (base + np.array(s.approach) * (ITEM_SIZE / 2) + np.array(s.lateral) * s.col_offsets[col]
            + np.array([0.0, 0.0, s.level_z[level]]))


@dataclass
class Item:
    name: str
    level: int                         # index into the shelf's level_z
    col: int                           # index into the shelf's col_offsets
    pos: np.ndarray = None             # centre of the cube (updated while the item is carried)
    R: np.ndarray = field(default_factory=lambda: np.eye(3))
    state: str = 'stored'              # stored | held | placed | skipped
    shelf: int = 0                     # index into config.SHELVES
    mass_kg: float = ITEM_MASS_KG

    def __post_init__(self):
        self.pos = item_center(self.shelf, self.level, self.col)

    @property
    def tool_R(self):
        return shelf_tool_R(self.shelf)

    @property
    def approach(self):
        return shelf_approach(self.shelf)


def make_items(orders):
    """[('A', level, col[, shelf[, mass_kg]]), ...] -> [Item, ...]"""
    items = []
    for o in orders:
        name, level, col = o[:3]
        items.append(Item(name, level, col, shelf=o[3] if len(o) > 3 else 0, mass_kg=o[4] if len(o) > 4 else ITEM_MASS_KG))
    return items


def tote_slot(k):
    """Place position for the k-th item: 2x2 grid in the tote, a second layer on top after 4 items."""
    dx, dy = [(-0.05, -0.05), (0.05, -0.05), (-0.05, 0.05), (0.05, 0.05)][k % 4]
    layer = k // TOTE_STACK_AFTER
    return np.array([TOTE_CENTER[0] + dx, TOTE_CENTER[1] + dy, TOTE_FLOOR_Z + ITEM_SIZE / 2 + layer * ITEM_SIZE])


@dataclass
class CyclePoses:
    """Every waypoint of one retrieve-and-place cycle (positions are TCP positions)."""
    grasp: np.ndarray
    pre_grasp: np.ndarray
    transit: np.ndarray
    pre_place: np.ndarray
    place: np.ndarray
    tool_R: np.ndarray          # tool orientation at the shelf

    def key_poses(self):
        """(name, position, orientation) list used for the reachability pre-check."""
        return [('pre-grasp', self.pre_grasp, self.tool_R), ('grasp', self.grasp, self.tool_R),
                ('transit', self.transit, R_DOWN), ('pre-place', self.pre_place, R_DOWN), ('place', self.place, R_DOWN)]


def cycle_key_poses(item: Item, slot_idx: int) -> CyclePoses:
    R = item.tool_R
    grasp = item.pos - R[:, 2] * ITEM_SIZE / 2          # TCP touches the face of the item that faces the robot
    slot = tote_slot(slot_idx)
    place = slot + np.array([0, 0, ITEM_SIZE / 2])       # TCP touches the item top
    return CyclePoses(grasp=grasp, pre_grasp=grasp - item.approach * STANDOFF, transit=TRANSIT_POINT.copy(),
                      pre_place=place + np.array([0, 0, PRE_PLACE_HEIGHT]), place=place, tool_R=R)
