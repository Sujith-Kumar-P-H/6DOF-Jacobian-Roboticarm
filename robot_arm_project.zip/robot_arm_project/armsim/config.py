"""
config.py -- EVERY number you may want to change lives here.

Nothing in this file does any computation. Other modules import these values.

Sections
  1. DH table        (robot geometry)           <- edit this to change the robot
  2. Robot limits    (joint range / speed / tool length / mounting)
  3. Controller gains
  4. Workcell        (shelf, items, tote, home posture)
  5. Output + visual settings
"""
from __future__ import annotations

import json
import math
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import List

import numpy as np


# =============================================================================================
# 1. DH TABLE
# =============================================================================================
@dataclass(frozen=True)
class DHRow:
    """One row of the DH table = one joint.

    theta_offset : constant added to the joint angle (rad). Joint variable q is added on top: theta = q + theta_offset
    d            : link offset along the joint axis [m]
    a            : link length [m]
    alpha        : link twist [rad]
    """
    d: float
    a: float
    alpha: float
    theta_offset: float = 0.0


@dataclass(frozen=True)
class DHTable:
    """The complete robot geometry.

    convention = 'standard'  : A_i = Rz(theta_i) Tz(d_i) Tx(a_i) Rx(alpha_i)        (textbook / Spong / Siciliano)
    convention = 'modified'  : A_i = Rx(alpha_i) Tx(a_i) Rz(theta_i) Tz(d_i)        (Craig; a_i, alpha_i belong to the link BEFORE joint i)

    The SAME physical robot has different numbers in the two conventions. Do not mix numbers between conventions.
    """
    rows: tuple
    convention: str = 'standard'
    name: str = 'custom'

    def __post_init__(self):
        if self.convention not in ('standard', 'modified'):
            raise ValueError("convention must be 'standard' or 'modified'")
        if len(self.rows) != 6:
            raise ValueError(f'this simulator needs exactly 6 DH rows, got {len(self.rows)}')

    # column views used by the kinematics code
    @property
    def d(self):
        return np.array([r.d for r in self.rows])

    @property
    def a(self):
        return np.array([r.a for r in self.rows])

    @property
    def alpha(self):
        return np.array([r.alpha for r in self.rows])

    @property
    def theta_offset(self):
        return np.array([r.theta_offset for r in self.rows])

    def pretty(self) -> str:
        lines = [f'DH table "{self.name}"  ({self.convention} convention)',
                 ' joint |  theta_offset[deg] |   d [m]   |   a [m]   | alpha [deg]',
                 '-------+--------------------+-----------+-----------+------------']
        for i, r in enumerate(self.rows, 1):
            lines.append(f'   {i}   | {math.degrees(r.theta_offset):>18.2f} | {r.d:>9.5f} | {r.a:>9.5f} | {math.degrees(r.alpha):>10.2f}')
        return '\n'.join(lines)

    # ---- load / save so the table can live in a small JSON file instead of code ----
    @staticmethod
    def from_json(path) -> 'DHTable':
        """JSON format (angles in DEGREES, lengths in METRES):
        {"name": "my robot", "convention": "standard",
         "rows": [{"d": 0.089159, "a": 0.0, "alpha_deg": 90, "theta_offset_deg": 0}, ... 6 rows ...]}"""
        data = json.loads(Path(path).read_text())
        rows = tuple(DHRow(d=float(r['d']), a=float(r['a']), alpha=math.radians(float(r['alpha_deg'])),
                           theta_offset=math.radians(float(r.get('theta_offset_deg', 0.0)))) for r in data['rows'])
        return DHTable(rows=rows, convention=data.get('convention', 'standard'), name=data.get('name', Path(path).stem))

    def to_json(self, path):
        data = dict(name=self.name, convention=self.convention,
                    rows=[dict(d=r.d, a=r.a, alpha_deg=math.degrees(r.alpha), theta_offset_deg=math.degrees(r.theta_offset))
                          for r in self.rows])
        Path(path).write_text(json.dumps(data, indent=2))


# ---- the factory table: UR5-style 6R arm, STANDARD DH (same numbers as your original script) ----
UR5_STANDARD = DHTable(
    name='UR5-style (standard DH)', convention='standard',
    rows=(
        DHRow(d=0.089159, a=0.0,      alpha=math.pi / 2),
        DHRow(d=0.0,      a=-0.425,   alpha=0.0),
        DHRow(d=0.0,      a=-0.39225, alpha=0.0),
        DHRow(d=0.10915,  a=0.0,      alpha=math.pi / 2),
        DHRow(d=0.09465,  a=0.0,      alpha=-math.pi / 2),
        DHRow(d=0.0823,   a=0.0,      alpha=0.0),
    ))

# ---- the SAME physical robot written in MODIFIED (Craig) DH. Used by the tests to prove both conventions work. ----
UR5_MODIFIED = DHTable(
    name='UR5-style', convention='modified',
    rows=(
        DHRow(d=0.089159, a=0.0,      alpha=0.0),
        DHRow(d=0.0,      a=0.0,      alpha=math.pi / 2),
        DHRow(d=0.0,      a=-0.425,   alpha=0.0),
        DHRow(d=0.10915,  a=-0.39225, alpha=0.0),
        DHRow(d=0.09465,  a=0.0,      alpha=math.pi / 2),
        DHRow(d=0.0823,   a=0.0,      alpha=-math.pi / 2),
    ))

DH_TABLE: DHTable = UR5_STANDARD       # <-- the table the simulation actually uses (override at run time with --dh file.json)


# =============================================================================================
# 2. ROBOT LIMITS AND MOUNTING
# =============================================================================================
@dataclass(frozen=True)
class RobotSpec:
    dh: DHTable = DH_TABLE
    q_lim: np.ndarray = field(default_factory=lambda: np.full(6, 2 * math.pi))   # +/- 360 deg per joint
    qd_lim: np.ndarray = field(default_factory=lambda: np.full(6, 2.0))          # rad/s used by the controller
    tool_len: float = 0.15                                                       # suction cup length along flange z [m]
    base_yaw: float = math.pi      # the UR5 DH base frame faces -x; yawing the base 180 deg makes the workcell face +x
    max_payload_kg: float = 5.0    # rated payload at the flange (UR5 class), INCLUDING the tool
    tool_mass_kg: float = 0.5      # suction cup + hose + bracket

    @property
    def item_payload_limit_kg(self) -> float:
        """Heaviest item the arm may pick = rated payload minus the tool."""
        return self.max_payload_kg - self.tool_mass_kg


ROBOT = RobotSpec()


# =============================================================================================
# 3. CONTROLLER GAINS  (two nested closed loops, 500 Hz)
# =============================================================================================
@dataclass(frozen=True)
class ControllerGains:
    # OUTER loop (task space, 1/s)
    Kp: float = 8.0          # position error gain
    Ko: float = 8.0          # orientation error gain
    k_null: float = 0.5      # null-space pull towards the home posture
    # INNER loop (joint PID, critically damped wn = 60 rad/s)
    Kpj: float = 3600.0
    Kdj: float = 120.0
    Kij: float = 40000.0
    bj: float = 2.0          # viscous friction
    acc_lim: float = 60.0    # rad/s^2
    i_clip: float = 0.05     # integrator anti-windup
    dt: float = 0.002        # 500 Hz
    # unknown constant disturbance (unmodelled gravity/friction) the I-term must reject, rad/s^2
    disturbance: np.ndarray = field(default_factory=lambda: np.array([0.3, -0.4, 0.2, 0.1, -0.1, 0.05]) * 5)


GAINS = ControllerGains()


# =============================================================================================
# 4. WORKCELL
# =============================================================================================
ITEM_SIZE = 0.06                        # cube edge [m]
ITEM_MASS_KG = 0.3                      # default item mass
SHELF_FRONT_X = 0.72                    # front face of shelf 1 (in front of the robot) [m]
BIN_Z = [0.22, 0.42, 0.62, 1.15]        # shelf levels (the top one is out of reach on purpose)
BIN_Y = [-0.20, 0.20]                   # two columns
STANDOFF = 0.20                         # pre-grasp distance in front of the item [m]
TOTE_CENTER = np.array([0.35, -0.50])
TOTE_FLOOR_Z = 0.05
HOME_Q = np.radians([0.0, -90.0, 90.0, -90.0, -90.0, 0.0])      # compact "ready" posture (joint angles)
TRANSIT_POINT = np.array([0.40, -0.25, 0.50])                   # free-space waypoint between shelf and tote
PRE_PLACE_HEIGHT = 0.15                                         # hover height above the tote slot [m]
# extra IK start postures (base turned +/-180 deg): needed to reach a shelf BEHIND the robot
EXTRA_IK_SEEDS = [HOME_Q + np.array([math.pi, 0, 0, 0, 0, 0]), HOME_Q - np.array([math.pi, 0, 0, 0, 0, 0])]


@dataclass(frozen=True)
class ShelfSpec:
    """One storage shelf. All vectors are in the robot base frame (x forward, y left, z up).
    front       (x, y) of the middle of the front face
    approach    unit vector from the robot INTO the shelf - the tool moves along it to retrieve an item
    lateral     unit vector along the row of columns
    y_hint      keeps the tool upright (any vector not parallel to `approach`)
    col_offsets position of each column along `lateral` [m];   level_z  height of each level [m]"""
    name: str
    front: tuple
    approach: tuple
    lateral: tuple
    y_hint: tuple
    col_offsets: tuple
    level_z: tuple


SHELVES = [
    ShelfSpec('shelf 1 (front)', front=(SHELF_FRONT_X, 0.0), approach=(1.0, 0.0, 0.0), lateral=(0.0, 1.0, 0.0),
              y_hint=(0.0, 1.0, 0.0), col_offsets=tuple(BIN_Y), level_z=tuple(BIN_Z)),
    ShelfSpec('shelf 2 (back)', front=(-SHELF_FRONT_X, 0.0), approach=(-1.0, 0.0, 0.0), lateral=(0.0, 1.0, 0.0),
              y_hint=(0.0, -1.0, 0.0), col_offsets=tuple(BIN_Y), level_z=tuple(BIN_Z)),
]
TOTE_STACK_AFTER = 4          # tote has a 2x2 grid; the 5th item and later are stacked on a second layer

# Suction gripper rules
SEAL_MAX_LATERAL = 0.006      # m
SEAL_MAX_DEPTH = 0.004        # m
SEAL_MAX_ANGLE_DEG = 8.0      # deg
VACUUM_SEALED_KPA = -62.0
VACUUM_LEAK_KPA = -4.0
VACUUM_OK_THRESHOLD_KPA = -40.0
MAX_GRASP_ATTEMPTS = 3

# Safety rules
FAULT_TRACKING_ERROR_M = 0.05       # stop the mission when the tracking error exceeds 50 mm
FLOOR_CLEARANCE_M = 0.02            # arm links must stay above this height

# The orders the mission works through: (name, level index, column index, shelf index, mass in kg)
# D is on the unreachable top level; H is heavier than the payload limit. Both are rejected on purpose.
DEFAULT_ORDERS = [('A', 0, 0, 0, 0.3), ('B', 1, 1, 0, 0.5), ('C', 2, 0, 0, 0.3), ('D', 3, 1, 0, 0.3),
                  ('E', 0, 1, 1, 0.8), ('F', 1, 0, 1, 1.2), ('G', 2, 1, 1, 0.4), ('H', 1, 1, 1, 6.5)]
BASELINE_ORDERS = [('A', 0, 0), ('B', 1, 1), ('C', 2, 0), ('D', 3, 1)]     # the original 4-order mission (shelf 1 only)


# =============================================================================================
# 5. OUTPUT AND VISUAL SETTINGS
# =============================================================================================
DEFAULT_OUT_DIR = 'C:/Users/sujit/OneDrive/Desktop/robot_arm_project'    # change this ONE line, or pass --out FOLDER


@dataclass
class VisualConfig:
    theme: str = 'dark'                          # 'dark' | 'light'
    font: str = ''                               # '' = automatic choice from the theme's font list
    font_scale: float = 1.0                      # 1.2 = 20 % bigger text everywhere
    panels: List[str] = field(default_factory=lambda: ['joints', 'error', 'manip', 'payload'])   # side graphs in video; see visuals/panels.py
    show_trace: bool = True                      # draw the TCP path trail in the 3D scene
    show_hud: bool = True                        # status text strip below the scene
    formats: List[str] = field(default_factory=lambda: ['png', 'mp4', 'gif', 'json'])
    fps_video: int = 20
    fps_gif: int = 12
    max_frames_video: int = 220
    max_frames_gif: int = 90
    dpi_video: int = 90
    dpi_gif: int = 55
    dpi_png: int = 130
    show_window: bool = False                    # True only when --show is passed


VISUALS = VisualConfig()
