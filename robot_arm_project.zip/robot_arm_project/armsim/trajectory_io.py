"""
trajectory_io.py -- save the whole run as ONE readable JSON file (trajectory.json), and load it back.

Layout of the file (angles in DEGREES, lengths in METRES, time in SECONDS):
    format, version
    units          what every number means
    robot          name, DH table, base yaw, tool length, payload rating, HOME posture
    run            seed, slip probability, time step, sampling period, total time, fault flag
    shelves        shelf geometry
    items          every item: name, shelf, level, column, mass, final state
    cycles         one entry per order: status, attempts, errors, cycle time, note
    events         time-stamped messages ("A sealed ...", "H rejected ...")
    phases         consecutive motion segments: label, t_start, t_end
    samples        COLUMN-wise arrays, all the same length N (easy to load into numpy / pandas):
                     t_s, joint_deg[N][6], joint_speed_dps[N][6], tcp_xyz_m[N][3], tracking_error_mm,
                     suction_on, payload_kg, phase (index into `phases`)

Load:   data = load_trajectory('trajectory.json');  q = np.array(data['samples']['joint_deg'])
"""
from __future__ import annotations

import json
import math
from dataclasses import asdict
from pathlib import Path

import numpy as np

from .config import HOME_Q, SHELVES


def _phases(d):
    """Merge consecutive samples that share a label into phases."""
    phases, idx = [], []
    for i, lab in enumerate(d.label):
        if not phases or phases[-1]['label'] != lab:
            phases.append({'label': lab, 't_start': round(float(d.t[i]), 4), 't_end': round(float(d.t[i]), 4)})
        phases[-1]['t_end'] = round(float(d.t[i]), 4)
        idx.append(len(phases) - 1)
    return phases, idx


def save_trajectory(path, arm, data, sim, mission, seed, slip):
    """Write the run to `path` (a .json file). Returns the file name."""
    d, spec = data, arm.spec
    phases, phase_idx = _phases(d)

    def clean(x):                                    # NaN is not valid JSON -> null
        return None if isinstance(x, float) and math.isnan(x) else x

    doc = {
        'format': 'armsim-trajectory', 'version': 1,
        'units': {'angles': 'degrees', 'length': 'metres', 'time': 'seconds', 'mass': 'kg', 'speed_joint': 'deg/s'},
        'robot': {
            'name': spec.dh.name, 'convention': spec.dh.convention,
            'dh_rows': [{'joint': i + 1, 'd_m': r.d, 'a_m': r.a, 'alpha_deg': math.degrees(r.alpha),
                         'theta_offset_deg': math.degrees(r.theta_offset)} for i, r in enumerate(spec.dh.rows)],
            'base_yaw_deg': math.degrees(spec.base_yaw), 'tool_length_m': spec.tool_len,
            'max_payload_kg': spec.max_payload_kg, 'tool_mass_kg': spec.tool_mass_kg,
            'item_payload_limit_kg': spec.item_payload_limit_kg,
            'home_joint_deg': [round(math.degrees(v), 4) for v in HOME_Q],
        },
        'run': {'seed': seed, 'slip_probability': slip, 'dt_s': sim.dt, 'sample_every_steps': sim.recorder.log_every,
                'sample_period_s': sim.dt * sim.recorder.log_every, 'total_time_s': round(sim.t, 4),
                'samples': int(len(d.t)), 'fault': bool(sim.fault)},
        'shelves': [{'name': s.name, 'front_xy_m': list(s.front), 'approach': list(s.approach),
                     'column_offsets_m': list(s.col_offsets), 'level_heights_m': list(s.level_z)} for s in SHELVES],
        'items': [{'name': it.name, 'shelf': it.shelf + 1, 'level': it.level, 'column': it.col, 'mass_kg': it.mass_kg,
                   'final_state': it.state} for it in sim.items],
        'cycles': [{k: clean(v) for k, v in asdict(r).items()} for r in mission.records],
        'events': [{'t_s': round(t, 3), 'message': m} for t, m in sim.events],
        'phases': phases,
        'samples': {
            't_s': np.round(d.t, 4).tolist(),
            'joint_deg': np.round(np.degrees(d.q), 4).tolist(),
            'joint_speed_dps': np.round(np.degrees(d.qd), 4).tolist(),
            'tcp_xyz_m': np.round(d.p, 6).tolist(),
            'tracking_error_mm': np.round(d.ep_mm, 4).tolist(),
            'suction_on': [bool(x) for x in d.suction],
            'payload_kg': np.round(d.payload_kg, 3).tolist(),
            'phase': phase_idx,
        },
    }
    path = Path(path)
    path.write_text(json.dumps(doc, separators=(',', ':'), allow_nan=False))
    return path.name


def load_trajectory(path):
    """Read a trajectory.json back as a plain dict."""
    doc = json.loads(Path(path).read_text())
    if doc.get('format') != 'armsim-trajectory':
        raise ValueError('not an armsim trajectory file')
    return doc
