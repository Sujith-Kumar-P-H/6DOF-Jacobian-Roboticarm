"""
controller.py -- the two nested closed loops (500 Hz).

    OUTER loop  ClikController  (task space)
        e        = [p_d - p ; log(R_d R^T)]            p, R measured from FK(q_measured)
        twist    = twist_feedforward + K e
        qd_cmd   = J_dls^+ twist + (I - J^+ J) k_null (q_home - q)       (null-space posture term)
        -> joint speed command, saturated keeping its direction

    INNER loop  JointServo  (joint space, PID)
        qdd = Kp (q_cmd - q) + Kd (qd_cmd - qd) + Ki * integral(e) - b qd + disturbance
        The disturbance is an unknown constant the I-term learns to reject.
    (decoupled unit-inertia model: NOT full rigid-body dynamics.)
"""
from __future__ import annotations

import numpy as np

from .config import GAINS, HOME_Q, ControllerGains
from .kinematics import Arm6
from .maths3d import R_to_rotvec


class ClikController:
    """Outer loop: turns a desired pose + twist into joint speed commands."""

    def __init__(self, arm: Arm6, gains: ControllerGains = GAINS):
        self.arm, self.g = arm, gains

    def command(self, q, p_d, R_d, v_d, w_d):
        """Returns (qd_cmd, e_p, e_o, J, p_measured)."""
        arm, g = self.arm, self.g
        p, R, J = arm.fk_jac(q)                                   # "measured" pose from the real joint state
        e_p, e_o = p_d - p, R_to_rotvec(R_d @ R.T)
        twist = np.concatenate([v_d + g.Kp * e_p, w_d + g.Ko * e_o])
        Jp = arm.dls_pinv(J)
        qd_cmd = Jp @ twist + (np.eye(6) - Jp @ J) @ (g.k_null * (HOME_Q - q))
        sc = np.max(np.abs(qd_cmd) / arm.qd_lim)
        if sc > 1.0:
            qd_cmd /= sc                                          # saturate keeping the direction
        return qd_cmd, e_p, e_o, J, p


class JointServo:
    """Inner loop: PID servo for every joint plus the (simulated) joint physics."""

    def __init__(self, arm: Arm6, q_start, gains: ControllerGains = GAINS):
        self.arm, self.g = arm, gains
        self.q_cmd = np.array(q_start, float).copy()
        self.I = np.zeros(6)

    def update(self, q, qd, qd_cmd):
        """Advance one time step. Returns the new (q, qd)."""
        g, dt = self.g, self.g.dt
        self.q_cmd = self.q_cmd + qd_cmd * dt
        e = self.q_cmd - q
        self.I = np.clip(self.I + e * dt, -g.i_clip, g.i_clip)
        u = g.Kpj * e + g.Kdj * (qd_cmd - qd) + g.Kij * self.I
        qdd = np.clip(u - g.bj * qd + g.disturbance, -g.acc_lim, g.acc_lim)
        qd = qd + qdd * dt
        q = np.clip(q + qd * dt, -self.arm.q_lim, self.arm.q_lim)
        return q, qd
