"""
mission.py -- the TASK layer: what the robot is asked to do and how a retrieve-and-place cycle goes.

One cycle (per item):
    1. reachability pre-check (IK on the 5 key poses)          -> otherwise SKIPPED
    2. approach pre-grasp (joint-space move)
    3. insert along +x, engage suction, check vacuum            -> retry up to MAX_GRASP_ATTEMPTS, else GRASP_FAIL
    4. retract along the same axis  (this is the "retrieval")
    5. transit, hover above the tote, lower, release, clear
Finally the mission returns to HOME.

Each finished cycle leaves one CycleRecord, which the report prints.
"""
from __future__ import annotations

import math
import time
from dataclasses import dataclass

import numpy as np

from .config import EXTRA_IK_SEEDS, FLOOR_CLEARANCE_M, HOME_Q, MAX_GRASP_ATTEMPTS
from .kinematics import Arm6
from .simulator import Simulator
from .workcell import Item, R_DOWN, cycle_key_poses


@dataclass
class CycleRecord:
    name: str
    status: str = '?'               # OK | SKIPPED | GRASP_FAIL | FAULT
    attempts: int = 0
    pick_pos_err: float = float('nan')     # [m]
    pick_ang_err: float = float('nan')     # [deg]
    mass_kg: float = 0.0
    time: float = 0.0                      # [s]
    note: str = ''


def check_reachable(arm: Arm6, poses, q_seed):
    """IK on every key pose of a cycle. Each is tried from two seeds because a tool-down pose cannot be reached from a
    tool-forward seed without a wrist flip. Returns (ok, reason)."""
    q = q_seed.copy()
    for name, p, R in poses:
        best, touches_floor = None, False
        for n, seed in enumerate((q, HOME_Q, *EXTRA_IK_SEEDS)):
            qi, ok, ep_, eo_ = arm.ik(p, R, seed)
            if n < 2:
                ep, eo = ep_, eo_                  # the message reports the residual of the two normal seeds
            if not ok:
                continue
            if arm.link_points(qi)[1:, 2].min() < FLOOR_CLEARANCE_M:
                touches_floor = True               # a valid solution, but this arm posture hits the floor: try the next seed
                continue
            best = qi
            break
        if best is None:
            if touches_floor:
                return False, f'{name}: arm would touch the floor'
            return False, f'{name}: IK failed (residual {ep*1000:.0f} mm / {math.degrees(eo):.0f} deg)'
        q = best
    return True, 'ok'


class PickingMission:
    def __init__(self, sim: Simulator):
        self.sim = sim
        self.records: list[CycleRecord] = []
        self.wall = 0.0
        self._shelf_of = {it.name: it.shelf for it in sim.items}

    # ------------------------------------------------------------------ one cycle
    def retrieve_and_place(self, item: Item, slot_idx, max_attempts=MAX_GRASP_ATTEMPTS):
        sim = self.sim
        t0 = sim.t
        rec = CycleRecord(name=item.name, mass_kg=item.mass_kg)
        self.records.append(rec)
        pose = cycle_key_poses(item, slot_idx)
        R_shelf = pose.tool_R

        limit = sim.arm.spec.item_payload_limit_kg                 # payload rule: rated payload minus the tool
        if item.mass_kg > limit:
            item.state = 'skipped'
            rec.status = 'OVERLOAD'
            rec.note = f'mass {item.mass_kg:.1f} kg > payload limit {limit:.1f} kg'
            sim.events.append((sim.t, f'{item.name} rejected: {rec.note}'))
            return

        ok, why = check_reachable(sim.arm, pose.key_poses(), sim.q)
        if not ok:
            item.state = 'skipped'
            rec.status, rec.note = 'SKIPPED', why
            sim.events.append((sim.t, f'{item.name} skipped: {why}'))
            return

        if not sim.goto_joint(pose.pre_grasp, R_shelf, f'{item.name}: approach pre-grasp'):
            rec.status, rec.note = 'FAULT', 'tracking fault'
            return

        grasped = False
        for attempt in range(1, max_attempts + 1):
            rec.attempts = attempt
            if not sim.goto(pose.grasp, R_shelf, f'{item.name}: insert into bin', v_lin=0.10):
                rec.status, rec.note = 'FAULT', 'tracking fault'
                return
            tcp_p, tcp_R = sim.arm.fk(sim.q)
            good, lat, dep, ang = sim.gripper.engage(item, tcp_p, tcp_R, sim.dwell)
            p_now, _ = sim.arm.fk(sim.q)
            rec.pick_pos_err = float(np.linalg.norm(pose.grasp - p_now))
            rec.pick_ang_err = ang
            if good:
                grasped = True
                sim.events.append((sim.t, f'{item.name} sealed, vacuum {sim.gripper.vacuum:.0f} kPa (attempt {attempt})'))
                break
            sim.events.append((sim.t, f'{item.name} NO SEAL (vacuum {sim.gripper.vacuum:.0f} kPa) - retry {attempt}/{max_attempts}'))
            sim.gripper.abort()
            sim.goto(pose.pre_grasp, R_shelf, f'{item.name}: back off for retry', v_lin=0.10)

        if not grasped:
            item.state = 'skipped'
            rec.status, rec.time, rec.note = 'GRASP_FAIL', sim.t - t0, 'gave up after retries'
            return

        sim.goto(pose.pre_grasp, R_shelf, f'{item.name}: retract from bin', v_lin=0.10)       # retrieval = same axis out
        sim.goto_joint(pose.transit, R_DOWN, f'{item.name}: transit to shelf')
        sim.goto(pose.pre_place, R_DOWN, f'{item.name}: above shelf')
        sim.goto(pose.place, R_DOWN, f'{item.name}: lower into shelf', v_lin=0.12)
        sim.gripper.release(sim.dwell)
        sim.goto(pose.pre_place, R_DOWN, f'{item.name}: clear shelf', v_lin=0.20)
        rec.status, rec.time = 'OK', sim.t - t0
        sim.events.append((sim.t, f'{item.name} placed in shelf'))

    # ------------------------------------------------------------------ whole mission
    def run(self):
        w0 = time.perf_counter()
        slot = 0
        for it in self.sim.items:
            if self.sim.fault:
                break
            self.retrieve_and_place(it, slot)
            if it.state == 'placed':
                slot += 1
        if not self.sim.fault:
            self.sim.go_home()
        self.wall = time.perf_counter() - w0

    # ------------------------------------------------------------------ text report
    def report(self, data):
        """`data` is the RunData from sim.recorder.finish()."""
        L = ['=' * 92, f"{'item':<6}{'shelf':>6}{'mass[kg]':>9}  {'status':<11}{'tries':>5}{'pos err[mm]':>12}{'ang err[deg]':>13}{'cycle[s]':>9}  note"]
        for r in self.records:
            pe = '-' if np.isnan(r.pick_pos_err) else f"{r.pick_pos_err*1000:.3f}"
            ae = '-' if np.isnan(r.pick_ang_err) else f"{r.pick_ang_err:.2f}"
            L.append(f"{r.name:<6}{self._shelf_of.get(r.name, 0) + 1:>6}{r.mass_kg:>9.1f}  {r.status:<11}{r.attempts:>5}{pe:>12}{ae:>13}{r.time:>9.1f}  {r.note}")
        ok = [r for r in self.records if r.status == 'OK']
        L.append('-' * 92)
        L.append(f"Payload: rated {self.sim.arm.spec.max_payload_kg:.1f} kg - tool {self.sim.arm.spec.tool_mass_kg:.1f} kg = "
                 f"{self.sim.arm.spec.item_payload_limit_kg:.1f} kg max item mass")
        L.append(f"Successful retrieve-and-place cycles : {len(ok)} / {len(self.records)} orders   "
                 f"mean cycle {np.mean([r.time for r in ok]) if ok else 0:.1f} s")
        L.append(f"Total simulated time {self.sim.t:.1f} s (wall {self.wall:.1f} s) | max task error {data.ep_mm.max():.1f} mm "
                 f"| min manipulability {data.w.min():.2e} | min sigma_min {data.smin.min():.3f}")
        L.append('=' * 92)
        return '\n'.join(L)
