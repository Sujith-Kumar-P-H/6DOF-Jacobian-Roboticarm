# 6-Axis Retrieval and Order-Picking Cell

![Python](https://img.shields.io/badge/python-3.x-blue)
![Dependencies](https://img.shields.io/badge/deps-NumPy%20%7C%20Matplotlib-informational)
![Status](https://img.shields.io/badge/scope-simulation%20only-lightgrey)

A pure-Python simulation of a 6-axis arm that starts at HOME, reaches into shelf bins, picks items with a suction cup, checks the grip, and places them in a tote. The cell has two shelves (front and back), a payload limit, dark-themed images, video and GIF output, and a JSON trajectory export.

**Pure Python: NumPy + Matplotlib.** No ROS, no GPU. Simulation only.

<!-- After a run, copy arm6_picking.gif into the repo (e.g. docs/) and uncomment:
![Demo](docs/arm6_picking.gif)
-->

## Features

- 6-axis arm driven entirely by an editable DH table (forward kinematics, Jacobian, inverse kinematics, reachability)
- Two shelves (front and one behind the robot) with eight orders of different masses
- Suction grip check with random seal failures and retry
- Payload rule: heavy items are rejected before the arm moves
- Dark/light themes, live graphs next to the 3D view, interactive window with toggles
- Exports PNG, MP4, GIF and a full `trajectory.json`

## Install

```bash
pip install -r requirements.txt
```

## Run

```bash
python3 pick_place_robot.py              # saves images + mp4 + gif + trajectory.json, opens NO window
python3 pick_place_robot.py --show       # same, and ALSO opens the live window with check-box toggles
python3 pick_place_robot.py --test       # self-tests
python3 pick_place_robot.py --check-dh   # check the DH table after you edit it
```

Output files are saved to the folder set by `DEFAULT_OUT_DIR` in `armsim/config.py`; edit it to change the destination.

The full run takes about 3 minutes (35 s of simulation plus about 2.5 min rendering the video and GIF). For a quick look use `--formats png,json`.

### Options

| Option | Meaning |
|---|---|
| `--show` | also open the interactive window (files are saved either way) |
| `--theme dark\|light` | colour theme (default `dark`) |
| `--font "Segoe UI"` `--font-scale 1.2` | font family / bigger text |
| `--panels joints,error,manip,payload` | graphs next to the 3D view. Others: `orient`, `manip_w`, `velocity`, `speed`. Empty string = no graphs |
| `--formats png,mp4,gif,json` | what to save |
| `--no-trace` `--no-hud` | hide the TCP trail / the status strip |
| `--shelves 1` | front shelf only (the original 4-order mission) |
| `--seed N` `--slip P` | random grip failures |
| `--dh file.json` | use a DH table from a JSON file (see `my_dh_example.json`) |

In the `--show` window, the check boxes (bottom right) toggle each graph, the TCP trail and the status strip.

## Output

| File | Content |
|---|---|
| `arm6_picking.mp4`, `arm6_picking.gif` | 3D scene + graphs, dark theme |
| `dashboard_final.png`, `final_scene.png`, `tcp_path_3d.png` | still images of the scene |
| `joint_angles.png`, `joint_speeds.png`, `tracking_error.png`, `jacobian_singularity.png`, `payload.png` | graphs |
| `trajectory.json` | the whole run (see below) |

## Workcell and Orders

| Order | Shelf | Mass | Expected result |
|---|---|---|---|
| A, B, C | 1 (front) | 0.3 / 0.5 / 0.3 kg | picked and placed |
| D | 1, top level | 0.3 kg | skipped: out of reach (on purpose) |
| E, F, G | 2 (back, behind the robot) | 0.8 / 1.2 / 0.4 kg | picked and placed |
| H | 2 | 6.5 kg | rejected: `OVERLOAD` |

With the default seed, 6 of 8 orders succeed. Order E needs a second grip attempt (random seal failure).

## Payload

`RobotSpec.max_payload_kg = 5.0` (UR5 class) minus `tool_mass_kg = 0.5` gives a **4.5 kg** maximum item mass. The mission checks item mass before moving; heavier items are rejected as `OVERLOAD` and never touched. The video shows the carried load and the limit.

> **Limit:** the payload is a *rule*. The joint model is unit-inertia, so a heavier item does not slow the arm, sag the tool, or reduce suction hold. Suction force is not checked against weight.

## trajectory.json

Angles in degrees, lengths in metres, time in seconds.

```python
from armsim.trajectory_io import load_trajectory
import numpy as np

d = load_trajectory('trajectory.json')
t   = np.array(d['samples']['t_s'])
q   = np.array(d['samples']['joint_deg'])    # (N, 6)
tcp = np.array(d['samples']['tcp_xyz_m'])    # (N, 3)
print(d['phases'][:3])                       # label, t_start, t_end of every motion segment
```

Sections: `robot` (DH table, payload), `run`, `shelves`, `items`, `cycles` (per order), `events`, `phases`, `samples` (columns of equal length). Samples are logged every 10 ms. Tool orientation is not stored; recompute it from `joint_deg` with `Arm6.fk`.

## Editing the DH Table

The DH table is the only definition of the robot's shape. Forward kinematics, the Jacobian, inverse kinematics, the reachability check, the drawn robot and every trajectory are computed from it. Change a number and you get a different arm.

**Not** changed by the DH table (adjust these yourself if the new robot differs a lot):

- `HOME_Q` (home joint angles): the same angles give a different pose on a different robot
- Shelf, tote and transit positions: unreachable orders are skipped
- Joint limits, speed limits and payload (`RobotSpec`)
- Controller gains

Things to know:

1. **Use one convention.** Standard DH (`Rz Tz Tx Rx`) and modified/Craig DH (`Rx Tx Rz Tz`) give different numbers for the same robot. Set `convention` to match your source. `UR5_MODIFIED` in `config.py` is the same robot as `UR5_STANDARD`; a test proves both give identical results.
2. **Units:** metres and radians in Python (`math.radians(90)`); degrees in the JSON file (`alpha_deg`).
3. **`theta_offset`** is added to the joint angle. Use it when your robot's zero position differs from the table.
4. **A wrong table can still be self-consistent.** The Jacobian test only proves the Jacobian matches the table, not that the table matches your real robot. Compare the zero-pose tool position with your datasheet.
5. After every edit, run `python pick_place_robot.py --check-dh`. It checks units, orthonormality, the Jacobian, zero and HOME tool positions, whether each order is still reachable, and prints a diff against the factory table.

**Workflow:** copy `my_dh_example.json`, edit it, run `--check-dh --dh my_dh.json`, then `--dh my_dh.json` for the real run. The factory table in code stays untouched.

> `--test` includes a check of the factory UR5 zero pose. If you change the factory table in `config.py`, that one test will fail on purpose.

## Limitations

Simulation only. Joint dynamics are decoupled unit-inertia (no Coriolis, no gravity model). Collision checking is a floor test only. Suction is a rule plus random leak, not physics. No vision. Tote slots beyond 4 are stacked on a second layer. Nothing here demonstrates real-world safety, cycle time or reliability.

## Project Structure

See [`ARCHITECTURE.md`](ARCHITECTURE.md) for the module map and an "I want to change X → edit Y" guide.
