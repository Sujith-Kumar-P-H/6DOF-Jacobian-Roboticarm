#!/usr/bin/env python3
"""
pick_place_robot.py -- ENTRY POINT. This file only reads the command line and calls the modules in armsim/.

    python pick_place_robot.py                    run the mission, SAVE images + mp4 + gif + trajectory.json (no window)
    python pick_place_robot.py --show             same, and ALSO open the interactive window (with check-box toggles)
    python pick_place_robot.py --test             self-tests (no files written)
    python pick_place_robot.py --check-dh         check the DH table after you edited it (add --dh my_dh.json to test a file)

Common options
    --out FOLDER          where files go (default: ~/robotic_arm_output)
    --theme dark|light    --font "Segoe UI"   --font-scale 1.2
    --panels joints,error,manip,payload        graphs next to the 3D view (see armsim/visuals/panels.py)
    --formats png,mp4,gif,json                 what to save
    --no-trace  --no-hud                       hide the TCP trail / the status strip
    --shelves 1|2         use only the front shelf (original mission) or both shelves (default)
    --seed N --slip P     random grip failures

Where to change things:  see ARCHITECTURE.md ("I want to change ... -> edit ...").
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np

from armsim.config import DEFAULT_ORDERS, DEFAULT_OUT_DIR, DH_TABLE, ROBOT, RobotSpec, VisualConfig, DHTable


def parse_args(argv=None):
    ap = argparse.ArgumentParser(description='6-axis retrieval and order-picking cell simulation',
                                 formatter_class=argparse.RawDescriptionHelpFormatter, epilog=__doc__)
    ap.add_argument('--test', action='store_true', help='run the self-tests and exit')
    ap.add_argument('--check-dh', action='store_true', help='check the DH table and exit')
    ap.add_argument('--dh', type=str, default='', help='load the DH table from a JSON file (see my_dh_example.json)')
    ap.add_argument('--show', action='store_true', help='ALSO open the interactive window (files are always saved)')
    ap.add_argument('--seed', type=int, default=2)
    ap.add_argument('--slip', type=float, default=0.2, help='probability of a random seal failure per grip attempt')
    ap.add_argument('--shelves', type=int, choices=(1, 2), default=2)
    ap.add_argument('--out', type=str, default=str(DEFAULT_OUT_DIR))
    ap.add_argument('--theme', choices=('dark', 'light'), default='dark')
    ap.add_argument('--font', type=str, default='')
    ap.add_argument('--font-scale', type=float, default=1.0)
    ap.add_argument('--panels', type=str, default=None, help='comma list, e.g. joints,error (empty string = no graphs)')
    ap.add_argument('--formats', type=str, default=None, help='comma list of png,mp4,gif,json')
    ap.add_argument('--no-trace', action='store_true')
    ap.add_argument('--no-hud', action='store_true')
    return ap.parse_args(argv)


def build_visual_config(a) -> VisualConfig:
    v = VisualConfig(theme=a.theme, font=a.font, font_scale=a.font_scale, show_trace=not a.no_trace,
                     show_hud=not a.no_hud, show_window=a.show)
    if a.panels is not None:
        v.panels = [k.strip() for k in a.panels.split(',') if k.strip()]
    if a.formats is not None:
        v.formats = [k.strip() for k in a.formats.split(',') if k.strip()]
    from armsim.visuals.panels import PANELS
    bad = [k for k in v.panels if k not in PANELS]
    if bad:
        sys.exit(f"unknown panel(s) {bad}. Available: {', '.join(PANELS)}")
    return v


def main(argv=None):
    a = parse_args(argv)
    table = DHTable.from_json(a.dh) if a.dh else DH_TABLE
    spec = RobotSpec(dh=table, q_lim=ROBOT.q_lim, qd_lim=ROBOT.qd_lim, tool_len=ROBOT.tool_len, base_yaw=ROBOT.base_yaw,
                     max_payload_kg=ROBOT.max_payload_kg, tool_mass_kg=ROBOT.tool_mass_kg)

    if a.test:
        from armsim.selftest import run_tests
        sys.exit(0 if run_tests() else 1)
    if a.check_dh:
        from armsim.dh_check import check_dh
        sys.exit(0 if check_dh(table, spec) else 1)

    from armsim.kinematics import Arm6
    from armsim.mission import PickingMission
    from armsim.simulator import Simulator
    from armsim.workcell import make_items

    vis = build_visual_config(a)
    arm = Arm6(spec)
    orders = [o for o in DEFAULT_ORDERS if o[3] < a.shelves]
    sim = Simulator(arm, make_items(orders), np.random.default_rng(a.seed), slip_prob=a.slip)
    mission = PickingMission(sim)
    print(f'Simulating mission ({len(orders)} orders, {a.shelves} shelf/shelves, robot "{table.name}") ...')
    mission.run()
    data = sim.recorder.finish()
    print(mission.report(data))
    for t, m in sim.events:
        print(f'  t={t:6.1f}s  {m}')

    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    saved = []
    if 'json' in vis.formats:
        from armsim.trajectory_io import save_trajectory
        saved.append(save_trajectory(out / 'trajectory.json', arm, data, sim, mission, a.seed, a.slip))
    if set(vis.formats) & {'png', 'mp4', 'gif'} or vis.show_window:
        print('Rendering images and video ..........')
        from armsim.visuals import render_all
        saved += render_all(arm, data, vis, out)
    print(f'Saved to {out}:')
    for s in saved:
        print('   ', s)
    if vis.show_window:
        print('(window closed)')


if __name__ == '__main__':
    main()
